package com.app.aqua_sense;

import android.bluetooth.BluetoothDevice;
import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.nfc.Tag;
import android.os.Handler;
import android.util.Log;

import java.util.UUID;

public class YesBroadcastReceiver extends BroadcastReceiver {




    @Override
    public void onReceive(Context context, Intent intent) {


            Log.d("YesActivity", "User clicked Yes");



    }
}
