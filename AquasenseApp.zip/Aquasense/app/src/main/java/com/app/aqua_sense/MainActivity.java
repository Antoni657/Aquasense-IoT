package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;
import android.content.Intent;
import android.os.Bundle;
import android.os.Handler;
import android.view.View;
import android.view.animation.Animation;
import android.view.animation.AnimationUtils;
import android.widget.Button;
import android.widget.ImageView;

public class MainActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);

        ImageView imageView = findViewById(R.id.imageView3);

        // Load the fade-in animation
        Animation fadeInAnimation = AnimationUtils.loadAnimation(this, R.anim.fade_in);

        // Apply the animation to the ImageView
        imageView.startAnimation(fadeInAnimation);

        // Use a Handler to delay the transition to another activity
        new Handler().postDelayed(new Runnable() {
            @Override
            public void run() {
                // Start the new activity after the delay
                startActivity(new Intent(MainActivity.this, landingPage.class));

                // Finish the current activity to prevent going back to it
                finish();
            }
        }, 5000); // Delay in milliseconds (5 seconds)
    }
}
