package com.app.aqua_sense;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Log;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.FirebaseAuth;

public class ForgotPass extends AppCompatActivity {

    Button Fpass;
    TextInputEditText editTextEmail;
    TextInputLayout layoutEmail;


    String txtEmail;
    FirebaseAuth auth;
    TextView login;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_forgot_pass);

        auth = FirebaseAuth.getInstance();
        editTextEmail = findViewById(R.id.email);
        Fpass = findViewById(R.id.FPass);
        login = findViewById(R.id.login);
        layoutEmail = findViewById(R.id.emailLayout);


        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(ForgotPass.this, LoginPage.class));
                finish();
            }
        });



        editTextEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String email = charSequence.toString();

                if (TextUtils.isEmpty(email)) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Required");
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Invalid Gmail address");
                } else {
                    layoutEmail.setHelperText("Valid");
                    layoutEmail.setError("");
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
            }
        });


        Fpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email = String.valueOf(editTextEmail.getText());

                boolean isAllValid = true;

                if (TextUtils.isEmpty(email)) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Required");
                    isAllValid = false;
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Invalid Gmail address");
                    isAllValid = false;
                } else {
                    layoutEmail.setHelperText("Valid");
                    layoutEmail.setError("");
                }

                if (isAllValid) {
                    // Perform sign-up logic here

                    // ...
                } else {
                    // Notify the user that there are validation errors
                    Toast.makeText(ForgotPass.this, "Please correct the errors.", Toast.LENGTH_SHORT).show();
                }

                if (isAllValid) {
                    auth.sendPasswordResetEmail(email) // Fix here: Change txtEmail to email
                            .addOnCompleteListener(new OnCompleteListener<Void>() {
                                @Override
                                public void onComplete(@NonNull Task<Void> task) {
                                    if (task.isSuccessful()) {
                                        Toast.makeText(ForgotPass.this, "Check your Email", Toast.LENGTH_SHORT).show();
                                        startActivity(new Intent(ForgotPass.this, LoginPage.class));
                                        finish();
                                    } else {
                                        Toast.makeText(ForgotPass.this, "Error: " + task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                    }
                                }
                            });
                }
            }
        });



    }
}