package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.TimePickerDialog;
import android.content.Intent;
import android.os.Bundle;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.View;
import android.widget.Button;
import android.widget.CompoundButton;
import android.widget.EditText;
import android.widget.Switch;
import android.widget.TextSwitcher;
import android.widget.TextView;
import android.widget.TimePicker;
import android.widget.Toast;
import android.widget.ViewSwitcher;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.FirebaseFirestore;

import org.checkerframework.checker.nullness.qual.NonNull;

import java.util.HashMap;
import java.util.Locale;
import java.util.Map;


public class SetTime extends AppCompatActivity {

    TextView backButton, textViewUnit, units;
    EditText mLEditText;
    Button sleep, nextbtn;

    Switch switchOuncesMilliliters;

    int hour,minute;
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();
    private boolean isTimeSet = false;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_set_time);




        switchOuncesMilliliters = findViewById(R.id.switchOuncesMilliliters);

        textViewUnit = findViewById(R.id.textViewUnit);
        units = findViewById(R.id.units);
        updateUnitText();

        switchOuncesMilliliters.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton buttonView, boolean isChecked) {
                // Update the TextView when the Switch state changes
                updateUnitText();

                if (mLEditText.getText().length() > 0) {
                    double value = Double.parseDouble(mLEditText.getText().toString());

                    if (isChecked) {
                        // Convert from oz to ml and round off
                        double convertedValue = Math.round(value * 29.5735); // 1 oz = 29.5735 ml
                        mLEditText.setText(String.format(Locale.getDefault(), "%d", (int) convertedValue));
                    } else {
                        // Convert from ml to oz and round off
                        double convertedValue = Math.round(value / 29.5735); // 1 ml = 0.033814 oz
                        mLEditText.setText(String.format(Locale.getDefault(), "%d", (int) convertedValue));
                    }
                }
            }
        });


        sleep = findViewById(R.id.sleep);
        nextbtn = findViewById(R.id.nextbtn);
        backButton = findViewById(R.id.backButton);

         mLEditText = findViewById(R.id.ML);

        nextbtn.setEnabled(false);





        // Set the factory for TextSwitcher to create TextViews


        mLEditText.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int start, int count, int after) {
                // Not needed for this example
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int start, int before, int count) {
                // Not needed for this example
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Check the entered value and limit it to 10000
                if (!editable.toString().isEmpty()) {
                    double value = Double.parseDouble(editable.toString());
                    if (value > 3500) {
                        mLEditText.setText("3500");
                    }

                    // Enable the "Finish" button if the value is not 0
                    nextbtn.setEnabled(value != 0 && isTimeSet && isValidTimeRange());
                } else {
                    // Disable the "Finish" button if the value is empty
                    nextbtn.setEnabled(false);
                }
            }
        });


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(SetTime.this, LoginPage.class));
                finish();
            }
        });

    }
    private boolean isValidTimeRange() {
        return hour >= 18 && hour <= 23; // Assuming midnight is inclusive
    }

    private void updateUnitText() {
        if (switchOuncesMilliliters.isChecked()) {
            textViewUnit.setText("Milliliters");
            units.setText("ml");
        } else {
            textViewUnit.setText("Ounces");
            units.setText("oz");
        }
    }

    public void pmtimer(View view) {
        TimePickerDialog.OnTimeSetListener onTimeSetListener = new TimePickerDialog.OnTimeSetListener() {
            @Override
            public void onTimeSet(TimePicker timePicker, int selectHour, int selectMinute) {

                hour = selectHour;
                minute = selectMinute;
                sleep.setText(String.format(Locale.getDefault(), "%01d:%02d",hour,minute));
                isTimeSet = isValidTimeRange();

                // Enable the "Finish" button if the value in mLEditText is not 0
                double value = Double.parseDouble(mLEditText.getText().toString());
                nextbtn.setEnabled(value != 0 && isTimeSet);;
            }
        };
        TimePickerDialog timePickerDialog = new TimePickerDialog(this, onTimeSetListener, hour, minute, false);
        timePickerDialog.setTitle("Choose PM Only");
        timePickerDialog.show();
    }


    public void next(View view) {
        nextbtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                // Get the currently authenticated user
                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

                if (currentUser != null) {
                    // Get the user's email
                    String userEmail = currentUser.getEmail();

                    // Get the time and water_goal values
                    String time = sleep.getText().toString();
                    String waterGoal = mLEditText.getText().toString();
                    String unitsValue = switchOuncesMilliliters.isChecked() ? "ml" : "oz";
                    // Create a map to store the data
                    Map<String, Object> userData = new HashMap<>();
                    userData.put("sleeping_time", time);
                    userData.put("water_goal", waterGoal);
                    userData.put("units", unitsValue);
                    // Update the Firestore document with the user's email
                    FirebaseFirestore.getInstance()
                            .collection("users")
                            .document(userEmail)
                            .update(userData)
                            .addOnSuccessListener(new OnSuccessListener<Void>() {
                                @Override
                                public void onSuccess(Void aVoid) {
                                    // Document updated successfully
                                    Toast.makeText(SetTime.this, "Data saved to Firestore", Toast.LENGTH_SHORT).show();
                                    startActivity(new Intent(SetTime.this, HomePage.class));
                                    finish();
                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Failed to update document
                                    Toast.makeText(SetTime.this, "Failed to save data to Firestore", Toast.LENGTH_SHORT).show();
                                }
                            });
                } else {
                    // Handle the case where the user is not authenticated
                    Toast.makeText(SetTime.this, "User not authenticated", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

}