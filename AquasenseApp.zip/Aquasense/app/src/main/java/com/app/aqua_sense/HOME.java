package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.os.Bundle;

public class HOME extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home);
    }
}