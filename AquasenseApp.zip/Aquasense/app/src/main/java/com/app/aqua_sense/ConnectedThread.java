package com.app.aqua_sense;


import android.annotation.SuppressLint;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.bluetooth.BluetoothSocket;
import android.content.Context;
import android.content.Intent;
import android.os.Build;
import android.os.Handler;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;
import com.google.firebase.firestore.SetOptions;

import java.io.IOException;
import java.io.InputStream;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.Timer;
import java.util.TimerTask;

//Class that given an open BT Socket will
//Open, manage and close the data Stream from the Arduino BT device
public class ConnectedThread extends Thread {

    private static final String TAG = "ConnThread";
    private final BluetoothSocket mmSocket;
    private final InputStream mmInStream;
    private final static int ERROR_READ = 1;
    //    private final OutputStream mmOutStream;
    private static final int THRESHOLD_EXCEEDED_NOTIFICATION_ID = 1;

    private Context mContext;
    private Handler uiHandler;
    private String valueRead;


    private volatile boolean running = true;


    private static final int RANGE_THRESHOLD = 100; // Adjust as needed
 // 10 seconds, adjust as needed
    private ArrayList<Integer> dataBuffer = new ArrayList<>();
    private ArrayList<Integer> calMode = new ArrayList<>();
    private ArrayList<Integer> calModeYes = new ArrayList<>();

    private boolean thresholdExceeded = false;
    private boolean modeCalculationInProgress = false;
    private boolean modeCalculationForYesInProgress = false;

    boolean withinThreshold = true;
    private static final int DATA_BUFFER_SIZE = 12; // Adjust as needed
    private static final int CHECK_INTERVAL = 2000; // Interval to check for sudden changes, in milliseconds



    private volatile boolean isCalculating = false;
    private Thread calculationThread;
    private int lastMode = 0;


    public ConnectedThread(BluetoothSocket socket, Handler uiHandler, Context context) {
        mmSocket = socket;
        this.uiHandler = uiHandler;
        InputStream tmpIn = null;
        mContext = context;
        createNotificationChannel();
        fetchWaterVal();
        // Get the input and output streams; using temp objects because
        // member streams are final.
        try {
            tmpIn = socket.getInputStream();
        } catch (IOException e) {
            Log.e(TAG, "Error occurred when creating input stream", e);
        }

        //Input and Output streams members of the class
        //We wont use the Output stream of this project
        mmInStream = tmpIn;


    }

    private void fetchWaterVal() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());


            firestore.collection("notif-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .limit(1)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Log.e("notif", "failed getting dataa");

                                return;
                            }

                            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm", Locale.getDefault());
                            String currentTime = sdfTime.format(new Date());

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("water_value");
                                    if (intakeValue != null) {
                                        int waterValue = Integer.parseInt(intakeValue); // Assuming intakeValue is an integer
                                        lastMode = waterValue; // Set lastMode to the water intake value
                                        Log.d("notif", "Last mode set to: " + lastMode);
                                    } else {
                                        Toast.makeText(mContext, "There's still no drinking data. Fill up the bottle to start!", Toast.LENGTH_SHORT).show();
                                    }

                                }

                                // Notify the adapter of data change


                            } else {
                                // Handle errors while fetching data
                                Log.e("notif", "error");

                            }
                        }
                    });
        }
    }


    public String getValueRead() {
        return valueRead;
    }


    public void run() {
        byte[] buffer = new byte[1024];
        int bytes = 0; // bytes returned from read()

        String lastReceivedMessage = "";
        long lastMessageTime = System.currentTimeMillis();


        while (running) {
            try {
                bytes = mmInStream.read(buffer);

                // Convert the bytes to a String.
                String readMessage = new String(buffer, 0, bytes).trim();

                if (!readMessage.equals(lastReceivedMessage) || System.currentTimeMillis() - lastMessageTime > 2000) {
                    // If it's a new message or enough time has passed since the last one,
                    // log the received message and update the last message information
                    valueRead = readMessage;
                    // Log the received message
                    Log.d(TAG, "Received message: " + readMessage);

                    // Check for sudden changes in water level
//                    processData(Integer.parseInt(readMessage));
                    try {
                        int value = Integer.parseInt(readMessage);
                        processData(value);
                        realtimeLevel(value);
                    } catch (NumberFormatException e) {
                        // Handle the case where readMessage is not a valid integer
                        // For example, log an error message or take appropriate action
                        e.printStackTrace();
                    }
                }
            } catch (IOException e) {
                Log.e(TAG, "Input stream was disconnected", e);
                break;
            }

        }
    }

    private void realtimeLevel(int value) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String unit = "ml";
            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Get the current time for the subcollection document
            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = sdfTime.format(new Date());

            String intakeValue = "0";
            String waterVal = String.valueOf(value);

            // Create a map to store the data
            Map<String, Object> userData = new HashMap<>();

            userData.put("intake_value", intakeValue);
            userData.put("units",unit);
            userData.put("time", currentTime);
            userData.put("water_value", waterVal);
            userData.put("date", currentDate);

            // Add a new document with a unique ID to the "water_intake" subcollection for the current date
            firestore.collection("level-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)

                    .set(userData, SetOptions.merge())
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            // Document successfully written
//                            Log.d("FirestoreData", "DocumentSnapshot successfully written!");
                            // Display a success message or update UI as needed
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to write document
                            Log.w("FirestoreData", "Error writing document", e);
                        }
                    });
        }
    }


    private void processData(int currentValue) {
        dataBuffer.add(currentValue);

        if (dataBuffer.size() > DATA_BUFFER_SIZE) {
            dataBuffer.remove(0);
        }

        checkThreshold(currentValue);
    }

    private void checkThreshold(int currentValue) {
        int lastValue = dataBuffer.size() > 1 ? dataBuffer.get(dataBuffer.size() - 2) : currentValue;

        int difference = Math.abs(lastValue - currentValue);

        if (difference > RANGE_THRESHOLD) {
            Log.d(TAG, "Threshold exceeded: " + difference);

//            checkIfWithinRange(currentValue);
//                showThresholdNotification();

            if (!modeCalculationInProgress) {
                // If not in progress, execute calculateMode()
                dataBuffer.clear();

                calculateMode();
//                uiHandler.postDelayed(() -> calculateMode(), 12000);

            } else {
                // If calculateMode() is already in progress, do nothing
                Log.d(TAG, "calculateMode() is already in progress, skipping...");

            }


//                        calculateMode();


        }
    }




    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Threshold Exceeded";
            String description = "Notifications for threshold exceeded.";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("threshold_channel", name, importance);
            channel.setDescription(description);
            // Register the channel with the system
            NotificationManager notificationManager = mContext.getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }



    @SuppressLint("MissingPermission")
    private void showThresholdNotification() {
        Intent intent = new Intent(mContext, Bluetooth.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Create the notification
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext, "threshold_channel")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("Threshold Exceeded")
                .setContentText("Please wait for the water to settle.")
                .setContentIntent(pendingIntent)  // Keep for notification tap action
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setAutoCancel(true);

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(mContext);
        notificationManager.notify(THRESHOLD_EXCEEDED_NOTIFICATION_ID, builder.build());
    }


    @SuppressLint("MissingPermission")
    private void showNotification() {
        Intent intent = new Intent(mContext, Bluetooth.class);
        PendingIntent pendingIntent = PendingIntent.getActivity(mContext, 0, intent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Create Yes and No Intents with your desired actions (replace with your logic)



        // Vibrate and sound on notification
        long[] vibratePattern = {0, 300, 0, 300}; // Customize vibration pattern (optional)
        NotificationCompat.Builder builder = new NotificationCompat.Builder(mContext, "threshold_channel")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("Recording drink")
                .setContentText("Please put the bottle in a flat surface and wait 20s")
                .setContentIntent(pendingIntent)  // Keep for notification tap action
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setVibrate(vibratePattern)  // Set vibration pattern
                .setDefaults(NotificationCompat.DEFAULT_ALL)
;

        // Show the notification
        NotificationManagerCompat notificationManager = NotificationManagerCompat.from(mContext);
        notificationManager.notify(THRESHOLD_EXCEEDED_NOTIFICATION_ID, builder.build());

        // Reset notification defaults (cancel vibration & sound) after user action
        // Implement logic in your activity's `onNewIntent` method to handle Yes/No intents
        // and reset notification defaults (optional):
        notificationManager.cancel(THRESHOLD_EXCEEDED_NOTIFICATION_ID); // Cancel the notification
        builder.setDefaults(NotificationCompat.DEFAULT_LIGHTS); // Reset defaults (no sound/vibration)
        notificationManager.notify(THRESHOLD_EXCEEDED_NOTIFICATION_ID, builder.build()); // Re-notify with reset defaults
    }



//    private void checkIfWithinRange(int currentValue) {
//
//
//        for (int value : dataBuffer) {
//            int difference = Math.abs(value - currentValue);
//            if (difference < RANGE_THRESHOLD) {
//                Log.d(TAG, "Results are not within range."+difference);
//                calculateMode();
//
//                 // Exit loop if any result is not within range
//            }{
//
//            }
//        }
//
//
//    }


    private boolean checkModeRange(int currentMode) {
        int difference = Math.abs(currentMode - lastMode);

        if (difference > RANGE_THRESHOLD) {
            // Difference exceeds threshold
            Log.d(TAG, "Mode difference exceeded threshold: " + difference);
            if (!modeCalculationForYesInProgress) {
                // If not in progress, execute calculateModeForYesButton()
                showNotification();
                dataBuffer.clear();

                uiHandler.postDelayed(() -> {
                    calculateModeForYesButton();
                    // Reset the flag once calculateModeForYesButton() completes

                }, 0);
                return true;
            } else {
                // If already in progress, do nothing
                Log.d(TAG, "calculateModeForYesButton() is already in progress, skipping...");
            }
        }
        return false;
    }
    private void calculateMode() {
        // Set modeCalculationInProgress to true to prevent concurrent mode calculation
        if (modeCalculationInProgress)
            return;

        modeCalculationInProgress = true;

        // Start a 12-second timer
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Calculate mode of the data in dataBuffer



                Map<Integer, Integer> occurrences = new HashMap<>();
                for (int value : dataBuffer) {
                    if (occurrences.containsKey(value)) {
                        occurrences.put(value, occurrences.get(value) + 1);
                    } else {
                        occurrences.put(value, 1);
                    }
                }

                int mode = 0;
                int maxOccurrences = 0;
                for (Map.Entry<Integer, Integer> entry : occurrences.entrySet()) {
                    if (entry.getValue() > maxOccurrences) {
                        mode = entry.getKey();
                        maxOccurrences = entry.getValue();
                    }
                }


                if (mode < lastMode) {
                    // Proceed with range check
                    checkModeRange(mode);
                } else {
                    // Exit if mode is not less than last mode
                    Log.d(TAG, "current value is higher than the last mode.");
                    modeCalculationInProgress = false;
                    return;
                }

                // Update previous mode value
                Log.d(TAG, "modeRange mode: " +lastMode);
                // Notify UI with the mode value
                int finalMode = mode;
                uiHandler.post(() -> {
                    // Update UI with the calculated mode value
                    Log.d(TAG, "Mode of water level data: " + finalMode);
                });



                // Reset modeCalculationInProgress flag
                modeCalculationInProgress = false;
            }

        }, 16000); // 12 seconds

    }

    public void calculateModeForYesButton() {
        if (modeCalculationForYesInProgress)
            return;

        modeCalculationForYesInProgress = true;

        // Start a 12-second timer
        Timer timer = new Timer();
        timer.schedule(new TimerTask() {
            @Override
            public void run() {
                // Calculate mode of the data in dataBuffer
                Map<Integer, Integer> occurrences = new HashMap<>();
                for (int value : dataBuffer) {
                    if (occurrences.containsKey(value)) {
                        occurrences.put(value, occurrences.get(value) + 1);
                    } else {
                        occurrences.put(value, 1);
                    }
                }

                int mode = 0;
                int maxOccurrences = 0;
                for (Map.Entry<Integer, Integer> entry : occurrences.entrySet()) {
                    if (entry.getValue() > maxOccurrences) {
                        mode = entry.getKey();
                        maxOccurrences = entry.getValue();
                    }
                }


                // Update previous mode value

                // Notify UI with the mode value
                int finalMode = lastMode - mode;
                String waterVal = String.valueOf(mode);
                String finalModeString = String.valueOf(finalMode);
                saveWaterIntakeData(finalModeString, waterVal);

                uiHandler.post(() -> {
                    // Update UI with the calculated mode value
                    Log.d(TAG, "finalMode: " + finalMode);


                });

                // Reset modeCalculationInProgress flag
                modeCalculationForYesInProgress = false;
            }
        },20000); // 12 seconds
    }



    private void saveWaterIntakeData(String finalModeString, String waterVal) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String unit = "ml";
            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Get the current time for the subcollection document
            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = sdfTime.format(new Date());

            // Create a map to store the data
            Map<String, Object> userData = new HashMap<>();
            userData.put("intake_value", finalModeString);
            userData.put("water_value", waterVal);
            userData.put("units",unit);
            userData.put("time", currentTime);



            firestore.collection("notif-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .limit(1)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Log.e("notif", "failed getting dataa");

                                return;
                            }



                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("water_value");
                                    if (intakeValue != null) {
                                        int waterValue = Integer.parseInt(intakeValue); // Assuming intakeValue is an integer
                                         int diff = waterValue - Integer.parseInt(waterVal);
                                         if (diff > 100){


                                             firestore.collection("notif-history")
                                                     .document(userEmail)
                                                     .collection("water_intake")
                                                     .document(currentDate)
                                                     .collection("entries")  // Optional: You can create a subcollection for entries if needed
                                                     .add(userData)
                                                     .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                                         @Override
                                                         public void onSuccess(DocumentReference documentReference) {
                                                             // Document added successfully

                                                             // Display a success message or update UI as needed
                                                             Log.d(TAG, "last Mode data save  ");
                                                         }
                                                     })
                                                     .addOnFailureListener(new OnFailureListener() {
                                                         @Override
                                                         public void onFailure(@NonNull Exception e) {
                                                             // Failed to add document
                                                             Log.d(TAG, "last Mode data Not save  ");
                                                         }
                                                     });

                                         }

                                    } else {
                                        Log.d(TAG, " data Not save  ");
                                    }

                                }

                                // Notify the adapter of data change


                            } else {
                                // Handle errors while fetching data
                                Log.e("notif", "error");

                            }
                        }
                    });







        }
    }





    // Call this method from the main activity to shut down the connection.
    public void cancel() {
        try {
            mmSocket.close();
        } catch (IOException e) {
            Log.e(TAG, "Could not close the connect socket", e);
        }
    }


}