package com.app.aqua_sense;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.content.res.ColorStateList;
import android.media.Image;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class LoginPage extends AppCompatActivity {

    TextInputEditText editTextEmail, editTextPassword;

    TextInputLayout layoutEmail, layoutPassword;
    Button login;
    ImageView backButton;

    TextView signup, fpass;

    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);


        setContentView(R.layout.activity_login_page);

        layoutEmail = findViewById(R.id.emailLayout);
        layoutPassword = findViewById(R.id.passwordLayout);

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);
        fpass = findViewById(R.id.ForgotPass);
        backButton = findViewById(R.id.backButton);



        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(LoginPage.this, landingPage.class));
                finish();
            }
        });

        editTextPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16), new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters, numbers, and special characters
                return source.toString().replaceAll("[^a-zA-Z0-9!@#$%^&*()-_+=]", "");
            }
        }});
//        editTextEmail.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                String email = charSequence.toString();
//
//                if (TextUtils.isEmpty(email)) {
//                    layoutEmail.setHelperText("");
//                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.red));
//                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
//                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.red));
//                    layoutEmail.setError("Invalid Gmail address");
//                } else {
//                    layoutEmail.setHelperText("Valid");
//                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.green));
//                }
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                if (TextUtils.isEmpty(editable)) {
//                    layoutEmail.setError("");
//                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
//                }
//            }
//        });
//
//        editTextPassword.addTextChangedListener(new TextWatcher() {
//            @Override
//            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//            }
//
//            @Override
//            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
//                String password = charSequence.toString();
//
//                if (TextUtils.isEmpty(password)) {
//                    layoutPassword.setHelperText("");
//                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
//                    return;  // Return here to prevent further processing
//                }
//
//                // Clear the error when the user starts typing
//                layoutPassword.setError("");
//
//                if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
//                    layoutPassword.setHelperText("Strong Password");
//                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
//                    layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
//                } else {
//                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
//                    layoutPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
//                    layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
//                }
//
// // Validate confirm password whenever password changes
//            }
//
//            @Override
//            public void afterTextChanged(Editable editable) {
//                if (TextUtils.isEmpty(editable)) {
//                    layoutPassword.setError("");
//                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
//                }
//            }
//        });




        editTextEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                layoutEmail.setError(null);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Clear error when user starts typing

            }
        });

        editTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                layoutPassword.setError(null);
            }

            @Override
            public void afterTextChanged(Editable editable) {
                // Clear error when user starts typing

            }
        });






        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginPage.this, RegistrationPage.class);
                startActivity(intent);
                finish();
            }
        });

        fpass.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(LoginPage.this, ForgotPass.class);
                startActivity(intent);
                finish();
            }
        });

        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email, password;
                email = String.valueOf(editTextEmail.getText());
                password = String.valueOf(editTextPassword.getText());

                boolean isAllValid = true;

                if (TextUtils.isEmpty(email)) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Required");
                    isAllValid = false;
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Invalid Gmail address");
                    isAllValid = false;
                } else {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("");
                }

                // Validate Password
                if (TextUtils.isEmpty(password)) {
                    layoutPassword.setHelperText("");
                    layoutPassword.setError("Required");
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                    isAllValid = false;
                }

                // Clear the error when the user starts typing
                layoutPassword.setError("");

                if (TextUtils.isEmpty(password)) {

                    layoutPassword.setError("Required");
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                    isAllValid = false;
                }



//                if (password.length() >= 8) {
//                    Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
//                    Matcher matcher = pattern.matcher(password);
//                    boolean isPwdContainsSpeChar = matcher.find();
//
//                    if (isPwdContainsSpeChar) {
//                        layoutPassword.setHelperText("Strong Password");
//                    } else {
//
//                        layoutPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
//
//                        isAllValid = false;
//                    }
//                } else {
//                    // Validate strength of the password
//                    if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
//                        layoutPassword.setHelperText("Password Match");
//                        layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
//                    } else {
//                        layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
//                        layoutPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
//                        layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
//                        isAllValid = false;
//                    }
//                }



                // Your existing authentication logic here
                if (isAllValid) {
                    firebaseAuth.signInWithEmailAndPassword(email, password)
                            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                                @Override
                                public void onComplete(@NonNull Task<AuthResult> task) {
                                    if (task.isSuccessful()) {
                                        if (firebaseAuth.getCurrentUser().isEmailVerified()) {
                                            startActivity(new Intent(LoginPage.this, HomePage.class));
                                            Toast.makeText(LoginPage.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                                        } else {
                                            Toast.makeText(LoginPage.this, "Please verify your email id ", Toast.LENGTH_SHORT).show();
                                        }


                                    } else {
                                        Toast.makeText(LoginPage.this, "Invalid email or password!", Toast.LENGTH_SHORT).show();

                                        layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                                    }
                                }
                            });
                }else {
                    // Notify the user that there are validation errors
                    Toast.makeText(LoginPage.this, "Please correct the errors.", Toast.LENGTH_SHORT).show();
                }
            }
        });
    }

    private boolean containsUpperCase(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    // Add a method to check if the password contains at least one special character
    private boolean containsSpecialCharacter(String password) {
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
    private void checkTimeAndWaterGoal() {
        // Replace this with the actual logic to fetch data from Firestore
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            if (userEmail != null) {
                // Assume you have a Firestore collection named "users" and a document with the user's email
                DocumentReference userRef = firebaseFirestore.collection("users").document(userEmail);

                userRef.get().addOnCompleteListener(task -> {
                    if (task.isSuccessful()) {
                        DocumentSnapshot document = task.getResult();

                        if (document != null && document.exists()) {
                            // User document exists, check if time and water_goal are empty
                            String time = document.getString("sleeping_time");
                            String waterGoal = document.getString("water_goal");

                            if (TextUtils.isEmpty(time) || TextUtils.isEmpty(waterGoal)) {
                                // Time or water_goal is empty, navigate to SetTime activity
                                Intent intent = new Intent(LoginPage.this, SetTime.class);
                                startActivity(intent);
                                finish();
                            } else {
                                // Time and water_goal are not empty, navigate to Dashboard
                                Intent intent = new Intent(LoginPage.this, HomePage.class);
                                startActivity(intent);
                                finish();
                            }
                        } else {
                            // User document doesn't exist, handle accordingly
                            Toast.makeText(LoginPage.this, "User document not found in Firestore", Toast.LENGTH_SHORT).show();
                        }
                    } else {
                        // Handle the failure to fetch data from Firestore
                        Toast.makeText(LoginPage.this, "Failed to fetch user data from Firestore", Toast.LENGTH_SHORT).show();
                    }
                });
            } else {
                // User email is null, handle accordingly
                Toast.makeText(LoginPage.this, "User email is null", Toast.LENGTH_SHORT).show();
            }
        } else {
            // Current user is null, handle accordingly
            Toast.makeText(LoginPage.this, "Current user is null", Toast.LENGTH_SHORT).show();
        }
    }


    private boolean isValidGmail(String email) {
        // Add your Gmail validation logic here
        return android.util.Patterns.EMAIL_ADDRESS.matcher(email).matches() && email.endsWith("@gmail.com");
    }

    private boolean isValidPassword(String password) {
        // Add your password validation logic here (at least one capital letter and one number)
        return password.matches("^(?=.*[A-Z])(?=.*\\d).+$");
    }
}
