package com.app.aqua_sense;

import android.text.InputFilter;
import android.text.Spanned;

public class NumericInputFilter implements InputFilter {
    @Override
    public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
        // Only allow digits (0-9) to be entered
        for (int i = start; i < end; i++) {
            if (!Character.isDigit(source.charAt(i))) {
                return "";
            }
        }
        return null;
    }
}

