package com.app.aqua_sense;
import com.google.firebase.Timestamp;
public class DataClass {

    private String timestamp;
    private String intakeValue;
    private String unitsOfWater;



    // Constructor with data values
    public DataClass(String  timestamp, String intakeValue, String unitsOfWater) {
        this.timestamp = timestamp;
        this.intakeValue = intakeValue;
        this.unitsOfWater = unitsOfWater;
    }

    // Getter and setter methods
    public String getTimestamp() {
        return timestamp;
    }

    public void setTimestamp(String timestamp) {
        this.timestamp = timestamp;
    }

    public String getIntakeValue() {
        return intakeValue;
    }

    public void setIntakeValue(String intakeValue) {
        this.intakeValue = intakeValue;
    }

    public String getUnitsOfWater() {
        return unitsOfWater;
    }

    public void setUnitsOfWater(String unitsOfWater) {
        this.unitsOfWater = unitsOfWater;
    }

}
