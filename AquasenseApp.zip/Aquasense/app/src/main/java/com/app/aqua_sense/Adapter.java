package com.app.aqua_sense;

import android.content.Context;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.cardview.widget.CardView;
import androidx.recyclerview.widget.RecyclerView;

import java.util.List;

public class Adapter extends RecyclerView.Adapter<RecyclerView.ViewHolder> {
    private static final int VIEW_TYPE_ITEM = 0;
    private static final int VIEW_TYPE_EMPTY = 1;

    private Context context;
    private List<DataClass> dataList;

    public Adapter(Context context, List<DataClass> dataList) {
        this.context = context;
        this.dataList = dataList;
    }

    @NonNull
    @Override
    public RecyclerView.ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType) {
        if (viewType == VIEW_TYPE_EMPTY) {
            // Inflate layout for empty view
            View emptyView = LayoutInflater.from(parent.getContext()).inflate(R.layout.empty_data, parent, false);
            return new EmptyViewHolder(emptyView);
        } else {
            // Inflate layout for regular item view
            View itemView = LayoutInflater.from(parent.getContext()).inflate(R.layout.recycler_item, parent, false);
            return new MyViewHolder(itemView);
        }
    }

    @Override
    public void onBindViewHolder(@NonNull RecyclerView.ViewHolder holder, int position) {
        if (holder instanceof MyViewHolder) {
            // Bind data for regular item view
            MyViewHolder viewHolder = (MyViewHolder) holder;
            viewHolder.intake.setText(dataList.get(position).getIntakeValue());
            viewHolder.units.setText(dataList.get(position).getUnitsOfWater());
            viewHolder.time.setText(dataList.get(position).getTimestamp());
        }
        // No need to bind data for empty view
    }

    @Override
    public int getItemCount() {
        // Return 1 if dataList is empty, otherwise return the size of dataList
        return dataList.isEmpty() ? 1 : dataList.size();
        
    }

    @Override
    public int getItemViewType(int position) {
        // Return VIEW_TYPE_EMPTY if dataList is empty
        return dataList.isEmpty() ? VIEW_TYPE_EMPTY : VIEW_TYPE_ITEM;
    }

    // ViewHolder classes for regular item view and empty view

    private static class MyViewHolder extends RecyclerView.ViewHolder {
        TextView intake, units, time;
        CardView recCard;

        public MyViewHolder(@NonNull View itemView) {
            super(itemView);
            intake = itemView.findViewById(R.id.waterVal);
            units = itemView.findViewById(R.id.waterUnits);
            time = itemView.findViewById(R.id.waterTime);
        }
    }

    private static class EmptyViewHolder extends RecyclerView.ViewHolder {
        public EmptyViewHolder(@NonNull View itemView) {
            super(itemView);
            // You can customize the empty view here if needed
        }
    }
}
