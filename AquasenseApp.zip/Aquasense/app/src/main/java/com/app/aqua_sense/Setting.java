package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.app.Dialog;
import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.Button;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.RatingBar;
import android.widget.TextView;

import com.google.firebase.auth.FirebaseAuth;

public class Setting extends AppCompatActivity {
    LinearLayout bluetooth,rateapp,help, contactus;

    ImageView backbutton;
    Button logout;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_setting);

        bluetooth = findViewById(R.id.bluetooth);
        backbutton = findViewById(R.id.backbutton);
        logout = findViewById(R.id.logout);
        rateapp = findViewById(R.id.rateapp);
        help = findViewById(R.id.help);
        contactus = findViewById(R.id.contactus);

        bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Setting.this, Bluetooth.class);
                startActivity(intent);
            }
        });
        logout.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                FirebaseAuth.getInstance().signOut();

                Intent intent = new Intent(Setting.this, MainActivity.class);
                startActivity(intent);
            }
        });

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);

                // Finish the RecordsActivity to go back to the HomePage
                finish();
            }
        });
        rateapp.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                showRatingDialog();
            }
        });

        help.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Setting.this, Help.class);
                startActivity(intent);
            }
        });
        contactus.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(Setting.this, ContactUs.class);
                startActivity(intent);
            }
        });



    }

    private void showRatingDialog() {
        final Dialog ratingDialog = new Dialog(Setting.this);
        ratingDialog.setContentView(R.layout.rating_dialog); // Create a layout file for your dialog

        RatingBar ratingBar = ratingDialog.findViewById(R.id.ratingBar);

        // Set a listener for when the user submits the rating
        Button submitButton = ratingDialog.findViewById(R.id.submitButton);
        submitButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                float rating = ratingBar.getRating();
                // Do something with the rating (e.g., send it to a server)
                ratingDialog.dismiss(); // Dismiss the dialog
            }
        });

        ratingDialog.show();
    }
    }



