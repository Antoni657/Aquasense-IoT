package com.app.aqua_sense;

import static androidx.constraintlayout.widget.ConstraintLayoutStates.TAG;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;
import android.util.Log;
import android.widget.Toast;

import androidx.annotation.NonNull;

import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;

public class NotificationActionReceiver extends BroadcastReceiver {
    @Override
    public void onReceive(Context context, Intent intent) {
        String action = intent.getAction();
        if (action != null) {
            switch (action) {
                case "ACTION_YES":
                    // User confirmed drinking water
                    String intakeValue = intent.getStringExtra("intakeValue");
                    String units = intent.getStringExtra("units");
                    String time = intent.getStringExtra("time");
                    String waterVal = intent.getStringExtra("waterVal");

                    Toast.makeText(context, "Recording " + intakeValue + " " + units + " at " + time, Toast.LENGTH_SHORT).show();
                    Log.e("notif", "yes button");
saveWaterIntakeData(intakeValue, time, waterVal);
                    // Handle the action, e.g., record the event
                    break;
                case "ACTION_NO":
                    // User confirmed not drinking water
                    Toast.makeText(context, "Not recording water intake", Toast.LENGTH_SHORT).show();
                    // Handle the action, e.g., ignore the event
                    Log.e("notif", "no button");
                    break;
                default:
                    break;
            }
        }
    }
    private void saveWaterIntakeData(String intakeValue, String time, String waterVal) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String unit = "ml";
            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Get the current time for the subcollection document
            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = sdfTime.format(new Date());

            // Create a map to store the data
            Map<String, Object> userData = new HashMap<>();
            userData.put("intake_value", intakeValue);
            userData.put("units",unit);
            userData.put("time", time);
            userData.put("water_value", waterVal);
            userData.put("date", currentDate);


            // Add a new document with a unique ID to the "water_intake" subcollection for the current date
            firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")  // Optional: You can create a subcollection for entries if needed
                    .add(userData)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Document added successfully

                            // Display a success message or update UI as needed
                            Log.d(TAG, "last Mode data save  ");
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to add document
                            Log.d(TAG, "last Mode data Not save  ");
                        }
                    });
        }
    }


}
