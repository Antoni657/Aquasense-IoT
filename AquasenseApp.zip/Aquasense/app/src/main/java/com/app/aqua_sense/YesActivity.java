package com.app.aqua_sense;

import android.os.Bundle;
import android.util.Log;

import androidx.appcompat.app.AppCompatActivity;

public class YesActivity extends AppCompatActivity {

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // Add your logic here for when the user clicks "Yes"

        // For example, you can save the data or perform any other action
        // You can also finish this activity if no UI is needed
        Log.d("YesActivity", "User clicked Yes");
        finish();
    }

}