package com.app.aqua_sense;

import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.TextView;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Locale;

public class records extends AppCompatActivity {


    TextView backButton;
    RecyclerView recyclerView;
    List<DataClass> dataList;
    Adapter adapter;

    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_records);

        loadDataFromFirestore();

        backButton = findViewById(R.id.backButton);
        recyclerView = findViewById(R.id.recyclerview);

        dataList = new ArrayList<>();
        adapter = new Adapter(this, dataList);



        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);
        recyclerView.setAdapter(adapter);

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);

                // Finish the RecordsActivity to go back to the HomePage
                finish();
            }
        });

    }


    private void loadDataFromFirestore() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Toast.makeText(records.this, "Failed to fetch data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                return;
                            }

                            dataList.clear();  // Clear existing data

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("intake_value");
                                    String units = document.getString("units");
                                    String time = document.getString("time");

                                    DataClass data = new DataClass(time, intakeValue, units);
                                    dataList.add(data);
                                }

                                // Log the size of the dataList
                                Log.d("FirestoreData", "DataList size: " + dataList.size());

                                adapter.notifyDataSetChanged();  // Notify the adapter of data change

                            } else {
                                // Handle errors while fetching data
                                Toast.makeText(records.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }
    }
}