package com.app.aqua_sense;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class ProfilePage extends AppCompatActivity {

    TextView home, profile, Gmail, fname;
    TextView remaining, goal, streak, goal_units, dash_ml;
    ImageButton bluetooth;
    ImageView setting;
    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
    int goalValue;
    int consecutiveDaysStreak = 0;

    RecyclerView recyclerView;
    List<DataClass> dataList;
    Adapter adapter;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile_page);
        loadDataFromFirestore();
        fetchAndDisplayUserInfo();
        displayTotalWaterIntakeRealtime();

        home = findViewById(R.id.homeBtn);
        bluetooth = findViewById(R.id.bluetooth);

        setting = findViewById(R.id.setting);
        Gmail = findViewById(R.id.gmail);
        fname = findViewById(R.id.fname);
        dash_ml = findViewById(R.id.dash_ml);

        remaining = findViewById(R.id.remainings);
        goal = findViewById(R.id.goals);
        streak = findViewById(R.id.streak);
        recyclerView = findViewById(R.id.recyclerview);

        dataList = new ArrayList<>();
        adapter = new Adapter(this, dataList);
        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);
        // Receive data from intent extras
        if (currentUser != null) {
            // Retrieve the current user's email
            String userEmail = currentUser.getEmail();

            // Firestore instance
            FirebaseFirestore firestore = FirebaseFirestore.getInstance();

            // Reference to the user's document
            firestore.collection("users")
                    .document(userEmail)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    // Retrieve the water_goal value from the document
                                    Object waterGoal = document.get("water_goal");
                                    Object Units = document.get("units");









                                    // Check if water_goal is not null before setting it to TextView
                                    if (waterGoal != null && Units != null) {
                                        goalValue = convertAndRoundGoal(waterGoal, Units);
                                        Log.d("hatdog", String.valueOf(goalValue));
                                        dash_ml.setText((CharSequence) Units);




                                        remaining.setText(String.valueOf(waterGoal) + " " + (Units));







                                        if ("oz".equals(Units)) {
                                            // Convert milliliters to ounces (1 ml = 0.033814 ounces)
                                            double waterGoalInOunces = Double.parseDouble(String.valueOf(waterGoal)) * 0.033814;
                                            // Round off the ounces to the nearest whole number
                                            long roundedOunces = Math.round(waterGoalInOunces);
                                            dash_ml.setText(" oz");


                                            // Update remaining with the rounded value
                                            double remainingInOunces = Double.parseDouble(String.valueOf(waterGoal)) * 0.033814;
                                            long roundedRemaining = Math.round(remainingInOunces);
                                            remaining.setText(String.valueOf(roundedRemaining) + " oz");

                                            // Update your manual values accordingly for ounces

                                        } else if ("ml".equals(Units)) {
                                            // Units are in milliliters

                                            dash_ml.setText((CharSequence) Units);
                                            remaining.setText(String.valueOf(waterGoal) + " " + (Units));

                                            // Update your manual values accordingly for milliliters

                                        }


                                    }


                                }
                            }
                        }


                    });

        }


        home.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);

                // Finish the RecordsActivity to go back to the HomePage
                finish();
            }
        });



        setting.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, Setting.class);
                startActivity(intent);
            }
        });
        bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(ProfilePage.this, Bluetooth.class);
                startActivity(intent);
            }
        });






    }

    private void loadDataFromFirestore() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)  // Adjust this according to your requirements
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Toast.makeText(ProfilePage.this, "Failed to fetch data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                return;
                            }

                            dataList.clear();  // Clear existing data

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("intake_value");
                                    String units = document.getString("units");
                                    String time = document.getString("time");


                                    DataClass data = new DataClass(time, intakeValue, units);
                                    dataList.add(data);

                                }

                                adapter.notifyDataSetChanged();  // Notify the adapter of data change


                            } else {
                                // Handle errors while fetching data
                                Toast.makeText(ProfilePage.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }


    }



    private void displayTotalWaterIntakeRealtime() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            CollectionReference entriesReference = firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries");

            // Fetch initial data
            entriesReference.get().addOnSuccessListener(queryDocumentSnapshots -> {
                int totalWaterIntake = 0;

                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                    String intakeValueString = document.getString("intake_value");

                    if (intakeValueString != null && !intakeValueString.trim().isEmpty()) {
                        try {
                            int intakeValue = Integer.parseInt(intakeValueString.trim());
                            totalWaterIntake += intakeValue;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                }

                // Log the total water intake
                Log.d("FirestoreData", "Initial Total Water Intake: " + totalWaterIntake);

                // Fetch the water goal from Firestore
                int finalTotalWaterIntake = totalWaterIntake;
                firestore.collection("users")
                        .document(userEmail)
                        .get()
                        .addOnSuccessListener(documentSnapshot -> {
                            if (documentSnapshot.exists()) {
                                // Retrieve the water_goal value from the document
                                Object waterGoal = documentSnapshot.get("water_goal");
                                if (waterGoal != null) {
                                    int goalValue = convertAndRoundGoal(waterGoal, documentSnapshot.get("units"));

                                    // Update the remaining water with the updatedTotalWaterIntake and goalValue
                                    updateRemainingWater(finalTotalWaterIntake, goalValue);
                                } else {
                                    // Handle the case where water_goal is null
                                    Log.e("FirestoreData", "Water goal is null");
                                }
                            } else {
                                // Handle the case where the document doesn't exist
                                Log.e("FirestoreData", "Document doesn't exist for user: " + userEmail);
                            }
                        })
                        .addOnFailureListener(e -> {
                            // Handle any errors fetching the water goal
                            Log.e("FirestoreData", "Failed to fetch water goal: " + e.getMessage());
                        });
            }).addOnFailureListener(e -> {
                // Handle the case where initial data fetch fails
                Toast.makeText(ProfilePage.this, "Failed to fetch initial water intake data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }



    private void updateRemainingWater(int totalWaterIntake, int goalValue) {
//        ProgressBar progressBar = findViewById(R.id.progressBar);
        // Assuming you have a TextView with this ID
        TextView remainingWaterTextView = findViewById(R.id.remainings); // Replace with your TextView ID

        if (goalValue > 0) {
            // Calculate the remaining water to take
            int remainingWater = goalValue - totalWaterIntake;
            Log.d("FirestoreData", "Remaining Water: " + remainingWater);
            Log.d("FirestoreData", "Remaining Water: " + goalValue);
            // Calculate the percentage of completion
            double percentage = ((double) totalWaterIntake / goalValue) * 100;

            // Ensure the percentage is within the valid range [0, 100]
            percentage = Math.min(100, Math.max(0, percentage));

            // Set the maximum progress to 100 to represent 100%
//            progressBar.setMax(100);
//
//            // Update the progress bar
//            progressBar.setProgress((int) percentage);

            // Display only whole numbers for the percentage
            int roundedPercentage = (int) Math.round(percentage);
            goal.setText(String.valueOf(roundedPercentage) + "%");

            // Display the remaining water to take in another TextView
            if (remainingWater > 0) {
                remainingWaterTextView.setText(remainingWater + " "); // Display units if remaining
                Log.d("FirestoreData", String.valueOf(remainingWaterTextView));
            } else {
                remainingWaterTextView.setText("0"); // Display 0 if remaining water is 0 or less
                Log.d("FirestoreData", String.valueOf(remainingWaterTextView));
            }

            if (roundedPercentage == 100) {
                // Execute the saveStreakData method
                saveStreakData(1);
            }
        } else {
            // Handle the case where the goal is 0 or negative
//            progressBar.setProgress(0);
            remainingWaterTextView.setText("0");
            Log.d("FirestoreData", String.valueOf(remainingWaterTextView));// Display 0 if goal is 0 or negative
        }
    }


    private void saveStreakData(int streak) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Create a map to store streak data
            Map<String, Object> streakData = new HashMap<>();
            streakData.put("consecutive_days_streak", streak);
            streakData.put("timestamp", currentDate); // Include timestamp for reference

            // Add streak data to the "history" collection under the current date
            firestore.collection("users")
                    .document(userEmail)
                    .collection("history")
                    .document(currentDate)
                    .set(streakData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            // Streak data saved successfully
                            Log.d("StreakData", "Consecutive days streak saved: " + streak);

                            checkConsecutiveDays();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to save streak data
                            Log.e("StreakData", "Failed to save consecutive days streak", e);
                        }
                    });
        }
    }

    private void checkConsecutiveDays() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            // Fetch all goal achievement data from Firestore
            firestore.collection("users")
                    .document(userEmail)
                    .collection("history")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                List<DocumentSnapshot> documents = task.getResult().getDocuments();

                                // Reset streak count
                                consecutiveDaysStreak = 0;

                                if (documents.size() >= 2) {
                                    // Check if timestamps are consecutive
                                    // Check if timestamps are consecutive
                                    for (int i = 1; i < documents.size(); i++) {
                                        String todayTimestamp = documents.get(i).getString("timestamp");
                                        String yesterdayTimestamp = documents.get(i - 1).getString("timestamp");
                                        Log.d("StreakData", "Today Timestamp: " + todayTimestamp);
                                        Log.d("StreakData", "Yesterday Timestamp: " + yesterdayTimestamp);

                                        if (areDatesConsecutive(yesterdayTimestamp, todayTimestamp)) {
                                            consecutiveDaysStreak++;
                                            Log.d("StreakData", "" + consecutiveDaysStreak);
                                        } else {
                                            // Break the loop if consecutive days are not found

                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    streak.setText(String.valueOf(consecutiveDaysStreak));
                                                }
                                            });
                                            consecutiveDaysStreak = 0;
                                            break;
                                        }
                                    }

                                    if (consecutiveDaysStreak > 0) {
                                        // Display the streak count in your app UI
                                        displayStreakInUI(consecutiveDaysStreak);
                                        Log.d("StreakData", "" + consecutiveDaysStreak);


                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                streak.setText(String.valueOf(consecutiveDaysStreak));
                                            }
                                        });
                                    }
                                }

                                // Save streak data if there is a streak

                            }
                        }
                    });
        }
    }

    private void displayStreakInUI(int consecutiveDaysStreak) {
    }

    private boolean areDatesConsecutive(String todayTimestamp, String yesterdayTimestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        try {
            Date todayDate = sdf.parse(todayTimestamp);
            Date yesterdayDate = sdf.parse(yesterdayTimestamp);

            // Calculate the difference between today and yesterday in milliseconds
            long difference = todayDate.getTime() - yesterdayDate.getTime();

            // Check if the difference is exactly one day (24 * 60 * 60 * 1000 milliseconds)
            return difference == (24 * 60 * 60 * 1000);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }
    private int convertAndRoundGoal(Object waterGoal, Object units) {
        double waterGoalValue = Double.parseDouble(String.valueOf(waterGoal));

        if ("oz".equals(units)) {
            // Convert milliliters to ounces (1 ml = 0.033814 ounces)
            double waterGoalInOunces = waterGoalValue * 0.033814;
            // Round off the ounces to the nearest whole number
            return (int) Math.round(waterGoalInOunces);
        } else if ("ml".equals(units)) {
            // Units are in milliliters
            return (int) waterGoalValue;
        }

        return 0; // Handle unsupported units if needed
    }

    private void fetchAndDisplayUserInfo() {
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            if (userEmail != null) {
                FirebaseFirestore.getInstance().collection("users")
                        .document(userEmail)
                        .get()
                        .addOnCompleteListener(task -> {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document != null && document.exists()) {
                                    // User document exists, retrieve and display information
                                    String gmail = document.getString("email");
                                    String firstName = document.getString("fname");
                                    String middleName = document.getString("mname");
                                    String lastName = document.getString("lname");

                                    // Set the retrieved values to TextViews
                                    if (gmail != null) {
                                        Gmail.setText(gmail);
                                    }
                                    if (firstName != null && middleName != null && lastName != null) {
                                        String fullName = firstName + " " + middleName + " " + lastName;
                                        fname.setText(fullName);
                                    }
                                }
                            }
                        });
            }
        }
    }
    }


