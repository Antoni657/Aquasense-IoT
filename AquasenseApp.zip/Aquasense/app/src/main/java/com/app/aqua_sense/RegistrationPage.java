package com.app.aqua_sense;

import android.app.DatePickerDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.res.ColorStateList;
import android.os.Bundle;
import android.text.Editable;
import android.text.InputFilter;
import android.text.Spanned;
import android.text.TextUtils;
import android.text.TextWatcher;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.CheckBox;
import android.widget.CompoundButton;
import android.widget.DatePicker;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import com.google.android.gms.common.api.GoogleApiClient;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.android.material.dialog.MaterialAlertDialogBuilder;
import com.google.android.material.textfield.TextInputEditText;
import com.google.android.material.textfield.TextInputLayout;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.firestore.FirebaseFirestore;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.Locale;
import java.util.Map;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

public class RegistrationPage extends AppCompatActivity {

    TextInputEditText editTextEmail, editTextPassword, editTextConfirmPassword, editTextFirstName, editTextMiddleName, editTextLastName, editTextBirthday ; // Add editTextConfirmPassword
    TextInputLayout layoutEmail, layoutPassword, layoutConfirmPassword, layoutFirstName, layoutMiddleName, layoutLastName, layoutBirthday ;


    CheckBox checkBox;
    Button signup;

    LinearLayout backButton;
    TextView login;

    MaterialAlertDialogBuilder materialAlertDialogBuilder;
    FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();

    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();

    private static final int RC_SIGN_IN = 9001;
    private GoogleApiClient mGoogleApiClient;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_registration_page);
        editTextBirthday = findViewById(R.id.birthday);

        editTextEmail = findViewById(R.id.email);
        editTextPassword = findViewById(R.id.password);
        editTextConfirmPassword = findViewById(R.id.Cpassword); // Add this line
        editTextFirstName = findViewById(R.id.fname);
        editTextMiddleName = findViewById(R.id.mname);
        editTextLastName = findViewById(R.id.lname);
        login = findViewById(R.id.login);
        signup = findViewById(R.id.signup);
        backButton = findViewById(R.id.backButton);

        layoutBirthday = findViewById(R.id.birthdayLayout);
        layoutEmail = findViewById(R.id.emailLayout);
        layoutPassword = findViewById(R.id.passwordLayout);
        layoutConfirmPassword = findViewById(R.id.cpasswordLayout);
        layoutFirstName = findViewById(R.id.fnameLayout);
        layoutMiddleName = findViewById(R.id.mnameLayout);
        layoutLastName = findViewById(R.id.lnameLayout);

        checkBox = findViewById(R.id.check_id);
        layoutMiddleName.setHelperText("Optional");
        layoutMiddleName.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.black)));

        materialAlertDialogBuilder = new MaterialAlertDialogBuilder(this);
        signup.setEnabled(false);
 // Set background drawable

        checkBox.setOnCheckedChangeListener(new CompoundButton.OnCheckedChangeListener() {
            @Override
            public void onCheckedChanged(CompoundButton compoundButton, boolean b) {

                if (b) {
                    materialAlertDialogBuilder.setTitle("Terms and Conditions");
                    materialAlertDialogBuilder.setMessage("**Terms and Conditions for AquaSense: IoT Tumbler Sensor for Hydration Tracking**\n" +
                            "\n" +
                            "Welcome to AquaSense, the IoT Tumbler Sensor System designed to enhance your hydration habits through smart technology. Before using our services, we kindly request that you carefully read and understand the following terms and conditions. Your use of AquaSense implies your acceptance of these terms.\n" +
                            "\n" +
                            "1. Acceptance of Terms:\n" +
                            "   By using the AquaSense IoT Tumbler Sensor System, you acknowledge that you have read, understood, and agree to comply with these terms and conditions. If you do not agree with any part of these terms, please refrain from using our services.\n" +
                            "\n" +
                            "2. User Registration and Profiles:\n" +
                            "   - Users are required to register and create personalized profiles on the AquaSense mobile application.\n" +
                            "   - Personal information provided during registration must be accurate and up-to-date.\n" +
                            "   - Users are responsible for maintaining the confidentiality of their account credentials.\n" +
                            "\n" +
                            "3. IoT Tumbler Sensor Integration:\n" +
                            "   - Users are expected to use AquaSense IoT Tumbler Sensors in accordance with the provided guidelines.\n" +
                            "   - Any attempt to modify or manipulate the IoT Tumbler Sensor system is strictly prohibited.\n" +
                            "\n" +
                            "4. Customizable Hydration Preferences:\n" +
                            "   - AquaSense provides customizable hydration preferences to help users tailor their hydration goals and configurations.\n" +
                            "   - Users are responsible for setting realistic and safe hydration preferences based on personal factors such as age, weight, and exercise levels.\n" +
                            "\n" +
                            "5. Reminder Notifications:\n" +
                            "   - Users may receive reminder notifications to encourage consistent water consumption based on their chosen hydration goals.\n" +
                            "   - Users have the option to customize notification settings within the AquaSense mobile application.\n" +
                            "\n" +
                            "6. Real-Time Hydration Monitoring:\n" +
                            "   - AquaSense offers real-time monitoring of water usage through the IoT Tumbler Sensor.\n" +
                            "   - Users should rely on the provided data for informational purposes and not as a substitute for professional medical advice.\n" +
                            "\n" +
                            "7. User-Friendly Interface:\n" +
                            "   - AquaSense is committed to providing a user-friendly and intuitive interface for the mobile application.\n" +
                            "   - Users are encouraged to provide feedback to improve the overall user experience.\n" +
                            "\n" +
                            "8. Limitations:\n" +
                            "   - Users acknowledge the limitations of the system, including potential inaccuracies in sensor calibration and tumbler material transparency.\n" +
                            "   - The mobile application is the primary interface; a web-based interface is not included in the current scope.\n" +
                            "\n" +
                            "9. Privacy and Data Security:\n" +
                            "   - AquaSense prioritizes user privacy and employs security measures to protect user data.\n" +
                            "   - Users are encouraged to review the privacy policy for detailed information on data collection and usage.\n" +
                            "\n" +
                            "10. Termination of Services:\n" +
                            "   - AquaSense reserves the right to terminate or suspend services to users who violate these terms and conditions.\n" +
                            "\n" +
                            "11. Modifications to Terms:\n" +
                            "   - AquaSense may modify these terms and conditions at any time. Users will be notified of any changes, and continued use implies acceptance of the modified terms.\n" +
                            "\n" +
                            "12. Contact Information:\n" +
                            "   - For inquiries or assistance, users can contact AquaSense through the provided contact information.\n" +
                            "\n" +
                            "By using AquaSense, you agree to abide by these terms and conditions. We appreciate your commitment to hydration and hope that AquaSense contributes to your overall well-being.");
                    materialAlertDialogBuilder.setPositiveButton("Accept", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            signup.setEnabled(true);
                            dialogInterface.dismiss();
                        }
                    });
                    materialAlertDialogBuilder.setNegativeButton("Decline", new DialogInterface.OnClickListener() {
                        @Override
                        public void onClick(DialogInterface dialogInterface, int i) {
                            dialogInterface.dismiss();
                            checkBox.setChecked(false);
                        }
                    });

                    materialAlertDialogBuilder.show();
                } else {
                    signup.setEnabled(false);
                }
            }
        });




        editTextFirstName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters and spaces
                return source.toString().replaceAll("[^a-zA-Z ]", "");
            }
        }});

        editTextMiddleName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15), new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters and spaces
                return source.toString().replaceAll("[^a-zA-Z ]", "");
            }
        }});

                editTextLastName.setFilters(new InputFilter[]{new InputFilter.LengthFilter(15),new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters and spaces
                return source.toString().replaceAll("[^a-zA-Z ]", "");
            }
        }});

        editTextPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16), new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters, numbers, and special characters
                return source.toString().replaceAll("[^a-zA-Z0-9!@#$%^&*()-_+=]", "");
            }
        }});

        editTextConfirmPassword.setFilters(new InputFilter[]{new InputFilter.LengthFilter(16), new InputFilter() {
            @Override
            public CharSequence filter(CharSequence source, int start, int end, Spanned dest, int dstart, int dend) {
                // Only allow letters, numbers, and special characters
                return source.toString().replaceAll("[^a-zA-Z0-9!@#$%^&*()-_+=]", "");
            }
        }});



        editTextFirstName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String fullName = charSequence.toString();

                if (TextUtils.isEmpty(fullName)) {
                    layoutFirstName.setHelperText("");

                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else if (!fullName.matches("[a-zA-Z ]+")) {

                    layoutFirstName.setError("Only letters and spaces are allowed");
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else if (fullName.length() > 30) {

                    layoutFirstName.setError("Maximum 20 characters");
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else {
                    layoutFirstName.setHelperText("Valid");
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.green));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutFirstName.setError("");
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }

            }
        });



        editTextMiddleName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                layoutMiddleName.setHelperText("(Optional)");
                layoutMiddleName.setBoxStrokeColor(getResources().getColor(R.color.blue));
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String fullName = charSequence.toString();

                if (TextUtils.isEmpty(fullName)) {
                    layoutMiddleName.setHelperText("");
                    layoutMiddleName.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else if (!fullName.matches("[a-zA-Z ]+")) {
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutMiddleName.setError("Only letters and spaces are allowed");
                } else if (fullName.length() > 30) {
                    layoutFirstName.setBoxStrokeColor(getResources().getColor(R.color.red));;
                    layoutMiddleName.setError("Maximum 20 characters");
                } else {
                    layoutMiddleName.setHelperText("Valid");
                    layoutMiddleName.setBoxStrokeColor(getResources().getColor(R.color.green));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutMiddleName.setError("");
                    layoutMiddleName.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }
            }
        });


        editTextLastName.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String fullName = charSequence.toString();

                if (TextUtils.isEmpty(fullName)) {
                    layoutLastName.setHelperText("");
                    layoutLastName.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else if (!fullName.matches("[a-zA-Z ]+")) {
                    layoutLastName.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutLastName.setError("Only letters and spaces are allowed");
                } else if (fullName.length() > 30) {
                    layoutLastName.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutLastName.setError("Maximum 20 characters");
                } else {
                    layoutLastName.setHelperText("Valid");
                    layoutLastName.setBoxStrokeColor(getResources().getColor(R.color.green));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutLastName.setError("");
                    layoutLastName.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }
            }
        });
        editTextBirthday.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                showDatePickerDialog(v);
            }
        });

        editTextBirthday.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {

            }

            @Override
            public void afterTextChanged(Editable editable) {
                String birthdateString = editTextBirthday.getText().toString().trim();
                if (!birthdateString.isEmpty()) {
                    // Validate the entered birthdate
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                    try {
                        Date birthdate = sdf.parse(birthdateString);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(birthdate);
                        int yearOfBirth = calendar.get(Calendar.YEAR);
                        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                        int age = currentYear - yearOfBirth;
                        if (age < 18 || age > 80) {
                            // Display an error message or handle the invalid input accordingly
                            layoutBirthday.setError("Please enter a birthdate between 18 and above.");
                            layoutBirthday.setBoxStrokeColor(getResources().getColor(R.color.red));
                        } else {
                            layoutBirthday.setHelperText("valid");
                            layoutBirthday.setBoxStrokeColor(getResources().getColor(R.color.green));
                        }

                    } catch (ParseException e) {
                        e.printStackTrace();
                        // Handle parsing exception if any
                    }
                }
            }
        });




        // Add TextWatcher for Email validation
        editTextEmail.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String email = charSequence.toString();

                if (TextUtils.isEmpty(email)) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.red));
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutEmail.setError("Invalid Gmail address");
                } else {
                    layoutEmail.setHelperText("Valid");
                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.green));
                }
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutEmail.setError("");
                    layoutEmail.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }
            }
        });

        editTextPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                String password = charSequence.toString();

                if (TextUtils.isEmpty(password)) {
                    layoutPassword.setHelperText("");
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                    return;  // Return here to prevent further processing
                }

                // Clear the error when the user starts typing
                layoutPassword.setError("");

                if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
                    layoutPassword.setHelperText("Strong Password");
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
                    layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                } else {
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
                    layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                }

                validateConfirmPassword(); // Validate confirm password whenever password changes
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutPassword.setError("");
                    layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }
            }
        });

        editTextConfirmPassword.addTextChangedListener(new TextWatcher() {
            @Override
            public void beforeTextChanged(CharSequence charSequence, int i, int i1, int i2) {
            }

            @Override
            public void onTextChanged(CharSequence charSequence, int i, int i1, int i2) {
                validateConfirmPassword(); // Validate confirm password whenever confirm password changes
            }

            @Override
            public void afterTextChanged(Editable editable) {
                if (TextUtils.isEmpty(editable)) {
                    layoutConfirmPassword.setError("");
                    layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.blue)); // Replace with the original color
                }
            }
        });

// Add a method to validate confirm password




        login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(RegistrationPage.this, LoginPage.class);
                startActivity(intent);
                finish();
            }
        });

        signup.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                String email, password, confirmPassword, fname, mname, lname, birthdate;
                email = String.valueOf(editTextEmail.getText());
                password = String.valueOf(editTextPassword.getText());
                confirmPassword = String.valueOf(editTextConfirmPassword.getText());
                fname = String.valueOf(editTextFirstName.getText());
                mname = String.valueOf(editTextMiddleName.getText());
                lname = String.valueOf(editTextLastName.getText());
                birthdate = String.valueOf(editTextBirthday.getText());

                boolean isAllValid = true; // Flag to check if all fields are valid

                // Validate Full Name
                if (TextUtils.isEmpty(fname)) {
                    layoutFirstName.setHelperText("");
                    layoutFirstName.setError("Required");
                    isAllValid = false;
                } else if (!fname.matches("[a-zA-Z ]+")) {
                    layoutFirstName.setHelperText("");
                    layoutFirstName.setError("Only letters and spaces are allowed");
                    isAllValid = false;
                } else if (fname.length() > 30) {
                    layoutFirstName.setHelperText("");
                    layoutFirstName.setError("Maximum 30 characters");
                    isAllValid = false;
                } else {
                    layoutFirstName.setHelperText("Valid");
                    layoutFirstName.setError("");
                }

                // Validate Middle Name
                if (TextUtils.isEmpty(mname)) {

                } else if (!mname.matches("[a-zA-Z ]+")) {
                    layoutMiddleName.setHelperText("");
                    layoutMiddleName.setError("Only letters and spaces are allowed");
                    isAllValid = false;
                } else if (mname.length() > 30) {
                    layoutMiddleName.setHelperText("");
                    layoutMiddleName.setError("Maximum 30 characters");
                    isAllValid = false;
                } else {
                    layoutMiddleName.setHelperText("Valid");
                    layoutMiddleName.setError("");
                }

                // Validate Last Name
                if (TextUtils.isEmpty(lname)) {
                    layoutLastName.setHelperText("");
                    layoutLastName.setError("Required");
                    isAllValid = false;
                } else if (!lname.matches("[a-zA-Z ]+")) {
                    layoutLastName.setHelperText("");
                    layoutLastName.setError("Only letters and spaces are allowed");
                    isAllValid = false;
                } else if (lname.length() > 30) {
                    layoutLastName.setHelperText("");
                    layoutLastName.setError("Maximum 30 characters");
                    isAllValid = false;
                } else {
                    layoutLastName.setHelperText("Valid");
                    layoutLastName.setError("");
                }



                if (TextUtils.isEmpty(birthdate)) {
                    layoutBirthday.setError("Required");
                    isAllValid = false;
                } else {
                    // Validate the entered birthdate
                    SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.US);
                    try {
                        Date birthday = sdf.parse(birthdate);
                        Calendar calendar = Calendar.getInstance();
                        calendar.setTime(birthday);
                        int yearOfBirth = calendar.get(Calendar.YEAR);
                        int currentYear = Calendar.getInstance().get(Calendar.YEAR);
                        int age = currentYear - yearOfBirth;
                        if (age < 18 || age > 80) {
                            // Display an error message for invalid age range
                            layoutBirthday.setError("Invalid age. Must be between 18 and 80");
                            isAllValid = false;
                        } else {
                            layoutBirthday.setHelperText("Valid");
                            layoutBirthday.setBoxStrokeColor(getResources().getColor(R.color.green));
                        }

                    } catch (ParseException e) {
                        e.printStackTrace();
                        // Handle parsing exception if any
                    }
                }


                // Validate Email
                if (TextUtils.isEmpty(email)) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Required");
                    isAllValid = false;
                } else if (!Patterns.EMAIL_ADDRESS.matcher(email).matches() || !email.endsWith("@gmail.com")) {
                    layoutEmail.setHelperText("");
                    layoutEmail.setError("Invalid Gmail address");
                    isAllValid = false;
                } else {
                    layoutEmail.setHelperText("Valid");
                    layoutEmail.setError("");
                }

                // Validate Password
                if (TextUtils.isEmpty(confirmPassword)) {
                    layoutPassword.setHelperText("");
                    layoutPassword.setError("Required");
                    isAllValid = false;
                } else {
                    // Validate strength of the password
                    if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
                        layoutPassword.setHelperText("Strong Password");
                        layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
                    } else {
                        layoutPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                        layoutPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
                        layoutPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                        isAllValid = false;
                    }
                }


                // Validate Confirm Password
                if (TextUtils.isEmpty(confirmPassword)) {
                    layoutConfirmPassword.setHelperText("");
                    layoutConfirmPassword.setError("Required");
                    isAllValid = false;
                } else if (!confirmPassword.equals(password)) {
                    layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                    layoutConfirmPassword.setHelperText("Password Do Not Match");
                    layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                    isAllValid = false;
                } else {
                    // Validate strength of the password
                    if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
                        layoutConfirmPassword.setHelperText("Password Match");
                        layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
                        layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
                    } else {
                        layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                        layoutConfirmPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
                        layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
                        isAllValid = false;
                    }
                }


                // If all validations pass, proceed with your sign-up logic




if (isAllValid) {
    firebaseAuth.createUserWithEmailAndPassword(email, password)
            .addOnCompleteListener(new OnCompleteListener<AuthResult>() {
                @Override
                public void onComplete(@NonNull Task<AuthResult> task) {
                    if (task.isSuccessful()) {

                        saveUserDataToFirestore(email, fname, mname, lname, birthdate);

                        firebaseAuth.getCurrentUser().sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                if (task.isSuccessful()) {
                                    Toast.makeText(RegistrationPage.this, "User registered successfully, and verify your email id", Toast.LENGTH_SHORT).show();
                                } else {
                                    Toast.makeText(RegistrationPage.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                                }
                            }
                        });

                        Toast.makeText(RegistrationPage.this, "Sign up successful!", Toast.LENGTH_SHORT).show();
                        Intent intent = new Intent(RegistrationPage.this, LoginPage.class);
                        startActivity(intent);
                        finish();
                    } else {
                        Toast.makeText(RegistrationPage.this, "Authentication Failed", Toast.LENGTH_SHORT).show();

                    }
                }
            });
}

else {
    // Notify the user that there are validation errors
    Toast.makeText(RegistrationPage.this, "Please correct the errors.", Toast.LENGTH_SHORT).show();
}
            }
        });

        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                startActivity(new Intent(RegistrationPage.this, landingPage.class));
                finish();
            }
        });



    }

    private boolean containsUpperCase(String password) {
        for (char c : password.toCharArray()) {
            if (Character.isUpperCase(c)) {
                return true;
            }
        }
        return false;
    }

    // Add a method to check if the password contains at least one special character
    private boolean containsSpecialCharacter(String password) {
        Pattern pattern = Pattern.compile("[^a-zA-Z0-9]");
        Matcher matcher = pattern.matcher(password);
        return matcher.find();
    }
    private void validateConfirmPassword() {
        String confirmPassword = editTextConfirmPassword.getText().toString();
        String password = editTextPassword.getText().toString();

        if (TextUtils.isEmpty(confirmPassword)) {
            layoutConfirmPassword.setHelperText("");
            layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
        } else if (!confirmPassword.equals(password)) {
            layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
            layoutConfirmPassword.setHelperText("Passwords do not match");
            layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
        } else {
            // Validate strength of the password
            if (password.length() >= 8 && containsUpperCase(password) && containsSpecialCharacter(password)) {
                layoutConfirmPassword.setHelperText("Password Match");
                layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.green));
                layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.green)));
            } else {
                layoutConfirmPassword.setBoxStrokeColor(getResources().getColor(R.color.red));
                layoutConfirmPassword.setHelperText("Weak Password. Include Number, Uppercase, and Special Char");
                layoutConfirmPassword.setHelperTextColor(ColorStateList.valueOf(getResources().getColor(R.color.red)));
            }
        }
    }

    private void saveUserDataToFirestore(String email, String fullname, String middlename, String lastname, String birthdate) {

        String waterGoal = "3000"; // Fixed value for water goal
        String waterUnits = "ml";
        // Create a new user object with email and full name
        Map<String, Object> user = new HashMap<>();
        user.put("email", email);
        user.put("fname", fullname);
        user.put("mname", middlename);
        user.put("lname", lastname);
        user.put("birthdate", birthdate);
        user.put("water_goal", waterGoal);
        user.put("units", waterUnits);

        firebaseFirestore.collection("users")
                .document(email)
                .set(user)
                .addOnSuccessListener(new OnSuccessListener<Void>() {
                    @Override
                    public void onSuccess(Void aVoid) {
                        // Successfully saved user data to Firestore
                        Toast.makeText(RegistrationPage.this, "User data saved to Firestore", Toast.LENGTH_SHORT).show();
                    }
                })
                .addOnFailureListener(new OnFailureListener() {
                    @Override
                    public void onFailure(@NonNull Exception e) {
                        // Failed to save user data to Firestore
                        Toast.makeText(RegistrationPage.this, "Failed to save user data to Firestore", Toast.LENGTH_SHORT).show();
                    }
                });
    }
    private boolean isGmail(String email) {
        // Check if the email is a Gmail address
        return email.endsWith("@gmail.com");
    }

    private boolean isPasswordValid(String password) {
        // Check if the password contains at least one uppercase letter and one digit
        return password.matches("(?=.*[A-Z])(?=.*\\d).+");
    }

    public void showDatePickerDialog(View v) {
        Calendar calendar = Calendar.getInstance();
        int year = calendar.get(Calendar.YEAR);
        int month = calendar.get(Calendar.MONTH);
        int dayOfMonth = calendar.get(Calendar.DAY_OF_MONTH);

        DatePickerDialog datePickerDialog = new DatePickerDialog(this,
                new DatePickerDialog.OnDateSetListener() {
                    @Override
                    public void onDateSet(DatePicker view, int selectedYear,
                                          int monthOfYear, int dayOfMonth) {
                        // Set the chosen date to the birthday EditText
                        editTextBirthday.setText(selectedYear + "-" + (monthOfYear + 1) + "-" + dayOfMonth);
                    }
                }, year, month, dayOfMonth);
        datePickerDialog.show();
    }



}
