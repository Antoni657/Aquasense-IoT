package com.app.aqua_sense;

import static androidx.constraintlayout.widget.ConstraintLayoutStates.TAG;

import android.annotation.SuppressLint;
import android.content.DialogInterface;
import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageButton;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AlertDialog;
import androidx.appcompat.app.AppCompatActivity;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.Timestamp;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.CollectionReference;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

import cjh.WaveProgressBarlibrary.WaveProgressBar;

public class HomePage extends AppCompatActivity {

    TextView streakDay, remaining, goal, goals, goal_units, dash_ml, waterIntake, noRecords;
    TextView first_manual,waterLevel, second_manual, third_manual, fourth_manual, fifth_manual;

    TextView drink_history;

    LinearLayout first_btn, second_btn, third_btn, fourth_btn, fifth_btn , waterRecords, records;
    Button profile, refill;
    ImageButton bluetooth;

    EditText amount;
    ImageView icon;

    RecyclerView recyclerView;
    List<DataClass> dataList;
    Adapter adapter;
    DataClass androidData;
//    ProgressBar progressBar;
    WaveProgressBar progressBar, progressLevelBar;
    FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
    private static final int MAX_MILLILITERS = 1000;
    private static final int MAX_INPUT_LENGTH = 4;
    int goalValue;
    int consecutiveDaysStreak = 0;
    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_home_page);

        loadDataFromFirestore();
        displayTotalWaterIntakeRealtime();
        checkConsecutiveDays();
        waterLevelRealtime();
        fetchWaterVal();
        streakDay = findViewById(R.id.streak);
        waterIntake = findViewById(R.id.waterIntake);
        remaining = findViewById(R.id.remaining);
        goal = findViewById(R.id.goal);
        goals = findViewById(R.id.goals);
        records = findViewById(R.id.records);
        waterRecords = findViewById(R.id.waterRecords);
        progressBar = findViewById(R.id.progressBar);
        progressLevelBar = findViewById(R.id.progressLevelBar);
        goal_units = findViewById(R.id.goal_units);
        dash_ml = findViewById(R.id.dash_ml);
        refill = findViewById(R.id.bottle);
        waterLevel = findViewById(R.id.waterLevel);

//        noRecords = findViewById(R.id.noRecordsTextView);
        recyclerView = findViewById(R.id.recyclerview);

        dataList = new ArrayList<>();
        adapter = new Adapter(this, dataList);



//        first_manual = findViewById(R.id.first_manual);
//        second_manual = findViewById(R.id.second_manual);
//        third_manual = findViewById(R.id.third_manual);
//        fourth_manual = findViewById(R.id.fourth_manual);
//        fifth_manual = findViewById(R.id.fifth_manual);
//
//        first_btn = findViewById(R.id.first_btn);
//        second_btn= findViewById(R.id.second_btn);
//        third_btn = findViewById(R.id.third_btn);
//        fourth_btn = findViewById(R.id.fourth_btn);
//        fifth_btn = findViewById(R.id.fifth_btn);

//        drink_history = findViewById(R.id.drink_history);


        profile = findViewById(R.id.profile);
        bluetooth = findViewById(R.id.bluetooth);



        LinearLayoutManager layoutManager = new LinearLayoutManager(this);
        recyclerView.setLayoutManager(layoutManager);

        recyclerView.setAdapter(adapter);

        // Check if adapter has no data to display
//        if (dataList.isEmpty()) {
//            // Show "No record found" message
//            noRecords.setVisibility(View.VISIBLE);
//        } else {
//            // Hide "No record found" message
//            noRecords.setVisibility(View.GONE);
//        }


        if (currentUser != null) {
            // Retrieve the current user's email
            String userEmail = currentUser.getEmail();

            // Firestore instance
            FirebaseFirestore firestore = FirebaseFirestore.getInstance();

            // Reference to the user's document
            firestore.collection("users")
                    .document(userEmail)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<DocumentSnapshot>() {
                        @Override
                        public void onComplete(Task<DocumentSnapshot> task) {
                            if (task.isSuccessful()) {
                                DocumentSnapshot document = task.getResult();
                                if (document.exists()) {
                                    // Retrieve the water_goal value from the document
                                    Object waterGoal = document.get("water_goal");
                                    Object Units = document.get("units");

                                    // Check if water_goal is not null before setting it to TextView
                                    if (waterGoal != null && Units != null) {
                                        goalValue = convertAndRoundGoal(waterGoal, Units);

                                        goal.setText(String.valueOf(waterGoal));
                                        goal_units.setText(" " + String.valueOf(Units));
                                        dash_ml.setText((CharSequence) Units);


                                        remaining.setText(String.valueOf(waterGoal) + " " + (Units));



                                        if ("oz".equals(Units)) {
                                            // Convert milliliters to ounces (1 ml = 0.033814 ounces)
                                            double waterGoalInOunces = Double.parseDouble(String.valueOf(waterGoal)) * 0.033814;
                                            // Round off the ounces to the nearest whole number
                                            long roundedOunces = Math.round(waterGoalInOunces);
                                            goal.setText(String.valueOf(roundedOunces));
                                            goal_units.setText(" oz");
                                            dash_ml.setText(" oz");

                                            // Update remaining with the rounded value
                                            double remainingInOunces = Double.parseDouble(String.valueOf(waterGoal)) * 0.033814;
                                            long roundedRemaining = Math.round(remainingInOunces);
                                            remaining.setText(String.valueOf(roundedRemaining) + " oz");

                                            // Update your manual values accordingly for ounces
//                                            first_manual.setText("  4  ");
//                                            second_manual.setText("  8  ");
//                                            third_manual.setText("  12  ");
//                                            fourth_manual.setText("  16  ");
//                                            fifth_manual.setText("  20  ");
                                        } else if ("ml".equals(Units)) {
                                            // Units are in milliliters
                                            goal.setText(String.valueOf(waterGoal));
                                            goal_units.setText(" " + String.valueOf(Units));
                                            dash_ml.setText((CharSequence) Units);
                                            remaining.setText(String.valueOf(waterGoal) + " " + (Units));

                                            // Update your manual values accordingly for milliliters
//                                            first_manual.setText("118");
//                                            second_manual.setText("227");
//                                            third_manual.setText("355");
//                                            fourth_manual.setText("473");
//                                            fifth_manual.setText("591");
                                        }


                                    }


                                }
                            }
                        }
                    });

        }





        refill.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                FirebaseFirestore firestore = FirebaseFirestore.getInstance();
                FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

                if (currentUser != null) {
                    String userEmail = currentUser.getEmail();
                    String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());




                            // Get current time
                            String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    String totalWaterIntake = waterLevel.getText().toString();



                            // Log the total water intake
                            Log.d("FirestoreData", "Total Water value: " + totalWaterIntake);

                            String waterValue = String.valueOf(totalWaterIntake);

                            String unit = "ml";
                            String intakeValue = "0";

                            Map<String, Object> userData = new HashMap<>();

                            userData.put("intake_value", intakeValue);
                            userData.put("units",unit);
                            userData.put("time", currentTime);
                            userData.put("water_value", waterValue);
                            userData.put("date", currentDate);

                            // Add a new document with a unique ID to the "water_intake" subcollection for the current date
                            firestore.collection("notif-history")
                                    .document(userEmail)
                                    .collection("water_intake")
                                    .document(currentDate)
                                    .collection("entries")  // Optional: You can create a subcollection for entries if needed
                                    .add(userData)
                                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                                        @Override
                                        public void onSuccess(DocumentReference documentReference) {
                                            // Document added successfully

                                            // Display a success message or update UI as needed
                                            Log.d(TAG, "last Mode data save  ");
                                        }
                                    })
                                    .addOnFailureListener(new OnFailureListener() {
                                        @Override
                                        public void onFailure(@NonNull Exception e) {
                                            // Failed to add document
                                            Log.d(TAG, "last Mode data Not save  ");
                                        }
                                    });
                        }



            }
        });



        records.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePage.this, History.class));

            }
        });

        waterRecords.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePage.this, records.class));

            }
        });
        profile.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                startActivity(new Intent(HomePage.this, ProfilePage.class));

            }
        });
        bluetooth.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(HomePage.this, Bluetooth.class);
                startActivity(intent);
            }
        });






    }

    private void showConfirmationDialog() {
        AlertDialog.Builder builder = new AlertDialog.Builder(this);
        builder.setTitle("Confirmation")
                .setMessage("Do you want to save the input?")
                .setPositiveButton("Yes", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Call the method to save the input
                        saveWaterIntakeData(first_manual.getText().toString());
                    }
                })
                .setNegativeButton("No", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialogInterface, int i) {
                        // Do nothing if the user clicks "No"
                    }
                })
                .show();
    }


    private void checkConsecutiveDays() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            // Fetch all goal achievement data from Firestore
            firestore.collection("users")
                    .document(userEmail)
                    .collection("history")
                    .orderBy("timestamp", Query.Direction.DESCENDING)
                    .get()
                    .addOnCompleteListener(new OnCompleteListener<QuerySnapshot>() {
                        @Override
                        public void onComplete(@NonNull Task<QuerySnapshot> task) {
                            if (task.isSuccessful()) {
                                List<DocumentSnapshot> documents = task.getResult().getDocuments();

                                // Reset streak count
                                consecutiveDaysStreak = 0;

                                if (documents.size() >= 2) {
                                    // Check if timestamps are consecutive
                                    // Check if timestamps are consecutive
                                    for (int i = 1; i < documents.size(); i++) {
                                        String todayTimestamp = documents.get(i).getString("timestamp");
                                        String yesterdayTimestamp = documents.get(i - 1).getString("timestamp");
                                        Log.d("StreakData", "Today Timestamp: " + todayTimestamp);
                                        Log.d("StreakData", "Yesterday Timestamp: " + yesterdayTimestamp);

                                        if (areDatesConsecutive(yesterdayTimestamp, todayTimestamp)) {
                                            consecutiveDaysStreak++;
                                            Log.d("StreakData", "" + consecutiveDaysStreak);
                                        } else {
                                            // Break the loop if consecutive days are not found

                                            runOnUiThread(new Runnable() {
                                                @Override
                                                public void run() {
                                                    streakDay.setText(String.valueOf(consecutiveDaysStreak));
                                                }
                                            });
                                            consecutiveDaysStreak = 0;
                                            break;
                                        }
                                    }

                                    if (consecutiveDaysStreak > 0) {
                                        // Display the streak count in your app UI
                                        displayStreakInUI(consecutiveDaysStreak);
                                        Log.d("StreakData", "" + consecutiveDaysStreak);


                                        runOnUiThread(new Runnable() {
                                            @Override
                                            public void run() {
                                                streakDay.setText(String.valueOf(consecutiveDaysStreak));
                                            }
                                        });
                                    }
                                }

                                // Save streak data if there is a streak

                            }
                        }
                    });
        }
    }

    private boolean areDatesConsecutive(String todayTimestamp, String yesterdayTimestamp) {
        SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());

        try {
            Date todayDate = sdf.parse(todayTimestamp);
            Date yesterdayDate = sdf.parse(yesterdayTimestamp);

            // Calculate the difference between today and yesterday in milliseconds
            long difference = todayDate.getTime() - yesterdayDate.getTime();

            // Check if the difference is exactly one day (24 * 60 * 60 * 1000 milliseconds)
            return difference == (24 * 60 * 60 * 1000);
        } catch (ParseException e) {
            e.printStackTrace();
            return false;
        }
    }



    private boolean areTimestampsConsecutive(Timestamp todayTimestamp, Timestamp yesterdayTimestamp) {
        // Implement your logic to check if timestamps are consecutive (e.g., differ by one day)
        // For simplicity, I'm assuming consecutive days are considered if they are on the same day.
        Calendar cal1 = Calendar.getInstance();
        Calendar cal2 = Calendar.getInstance();
        cal1.setTime(todayTimestamp.toDate());
        cal2.setTime(yesterdayTimestamp.toDate());

        return cal1.get(Calendar.YEAR) == cal2.get(Calendar.YEAR) &&
                cal1.get(Calendar.DAY_OF_YEAR) - cal2.get(Calendar.DAY_OF_YEAR) == 1;
    }

    private void displayStreakInUI(int streak) {
        // Update your UI to display the consecutive days streak
        // For example, you can set the streak to a TextView or any other UI element.
    }



    private void saveStreakData(int streak) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();

            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Create a map to store streak data
            Map<String, Object> streakData = new HashMap<>();
            streakData.put("consecutive_days_streak", streak);
            streakData.put("timestamp", currentDate); // Include timestamp for reference

            // Add streak data to the "history" collection under the current date
            firestore.collection("users")
                    .document(userEmail)
                    .collection("history")
                    .document(currentDate)
                    .set(streakData)
                    .addOnSuccessListener(new OnSuccessListener<Void>() {
                        @Override
                        public void onSuccess(Void aVoid) {
                            // Streak data saved successfully
                            Log.d("StreakData", "Consecutive days streak saved: " + streak);

                            checkConsecutiveDays();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to save streak data
                            Log.e("StreakData", "Failed to save consecutive days streak", e);
                        }
                    });
        }
    }


    private void loadDataFromFirestore() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)  // Adjust this according to your requirements
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Toast.makeText(HomePage.this, "Failed to fetch data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
                                return;
                            }

                            dataList.clear();  // Clear existing data

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("intake_value");
                                    String units = document.getString("units");
                                    String time = document.getString("time");


                                    DataClass data = new DataClass(time, intakeValue, units);
                                    dataList.add(data);

                                }

                                adapter.notifyDataSetChanged();  // Notify the adapter of data change


                            } else {
                                // Handle errors while fetching data
                                Toast.makeText(HomePage.this, "Failed to fetch data", Toast.LENGTH_SHORT).show();
                            }
                        }
                    });
        }


    }



    private int convertAndRoundGoal(Object waterGoal, Object units) {
        double waterGoalValue = Double.parseDouble(String.valueOf(waterGoal));

        if ("oz".equals(units)) {
            // Convert milliliters to ounces (1 ml = 0.033814 ounces)
            double waterGoalInOunces = waterGoalValue * 0.033814;
            // Round off the ounces to the nearest whole number
            return (int) Math.round(waterGoalInOunces);
        } else if ("ml".equals(units)) {
            // Units are in milliliters
            return (int) waterGoalValue;
        }

        return 0; // Handle unsupported units if needed
    }

//    private void updateRemainingText(int maxValue, int progress) {
//        int remainingValue = maxValue - progress;
//        remaining.setText("" + remainingValue);
//    }
//
//
//    private void updateMlText(int progress) {
//        waterIntake.setText("" + progress + "ml");
//    }





    private void saveWaterIntakeData(String manualValue) {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String unit = goal_units.getText().toString();
            // Get the current date for the document ID
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            // Get the current time for the subcollection document
            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault());
            String currentTime = sdfTime.format(new Date());

            // Create a map to store the data
            Map<String, Object> userData = new HashMap<>();
            userData.put("intake_value", manualValue);
            userData.put("units",unit);
            userData.put("time", currentTime);


            // Add a new document with a unique ID to the "water_intake" subcollection for the current date
            firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")  // Optional: You can create a subcollection for entries if needed
                    .add(userData)
                    .addOnSuccessListener(new OnSuccessListener<DocumentReference>() {
                        @Override
                        public void onSuccess(DocumentReference documentReference) {
                            // Document added successfully

                            // Display a success message or update UI as needed
                            Toast.makeText(HomePage.this, "Water intake data saved successfully", Toast.LENGTH_SHORT).show();
                        }
                    })
                    .addOnFailureListener(new OnFailureListener() {
                        @Override
                        public void onFailure(@NonNull Exception e) {
                            // Failed to add document
                            Toast.makeText(HomePage.this, "Failed to save water intake data", Toast.LENGTH_SHORT).show();
                        }
                    });
        }
    }

    private void displayTotalWaterIntakeRealtime() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            CollectionReference entriesReference = firestore.collection("water-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries");

            // Fetch initial data
            entriesReference.get().addOnSuccessListener(queryDocumentSnapshots -> {
                int totalWaterIntake = 0;

                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                    String intakeValueString = document.getString("intake_value");

                    if (intakeValueString != null && !intakeValueString.trim().isEmpty()) {
                        try {
                            int intakeValue = Integer.parseInt(intakeValueString.trim());
                            totalWaterIntake += intakeValue;
                        } catch (NumberFormatException e) {
                            e.printStackTrace();
                        }
                    }
                }

                // Log the total water intake
                Log.d("FirestoreData", "Initial Total Water Intake: " + totalWaterIntake);

                // Update the TextView with the total water intake
                updateTextView(totalWaterIntake);

                // Attach listener for real-time updates
                entriesReference.addSnapshotListener((value, error) -> {
                    if (error != null) {
                        // Handle errors while fetching data
                        Toast.makeText(HomePage.this, "Failed to fetch water intake data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                        return;
                    }

                    int updatedTotalWaterIntake = 0;

                    if (value != null) {
                        for (QueryDocumentSnapshot document : value) {
                            String intakeValueString = document.getString("intake_value");

                            if (intakeValueString != null && !intakeValueString.trim().isEmpty()) {
                                try {
                                    int intakeValue = Integer.parseInt(intakeValueString.trim());
                                    updatedTotalWaterIntake += intakeValue;
                                } catch (NumberFormatException e) {
                                    e.printStackTrace();
                                }
                            }
                        }
                    }

                    // Log the updated total water intake
                    Log.d("FirestoreData", "Updated Total Water Intake: " + updatedTotalWaterIntake);

                    // Update the TextView with the updated total water intake
                    updateTextView(updatedTotalWaterIntake);

                    // Update the progress bar
                    updateProgressBar(updatedTotalWaterIntake, goalValue);
                });
            }).addOnFailureListener(e -> {
                // Handle the case where initial data fetch fails
                Toast.makeText(HomePage.this, "Failed to fetch initial water intake data: " + e.getMessage(), Toast.LENGTH_SHORT).show();
            });
        }
    }


    private void updateProgressBar(int totalWaterIntake, int goalValue) {
        WaveProgressBar progressBar = findViewById(R.id.progressBar);
         // Assuming you have a TextView with this ID
        TextView remainingWaterTextView = findViewById(R.id.remaining); // Replace with your TextView ID

        if (goalValue > 0) {
            // Calculate the remaining water to take
            int remainingWater = goalValue - totalWaterIntake;

            // Calculate the percentage of completion
            double percentage = ((double) totalWaterIntake / goalValue) * 100;

            // Ensure the percentage is within the valid range [0, 100]
            percentage = Math.min(100, Math.max(0, percentage));

            // Set the maximum progress to 100 to represent 100%
            progressBar.setMax(100);

            // Update the progress bar
            progressBar.setProgress((int) percentage);

            // Display only whole numbers for the percentage
            int roundedPercentage = (int) Math.round(percentage);
            goals.setText(String.valueOf(roundedPercentage) + "%");

            // Display the remaining water to take in another TextView
            if (remainingWater > 0) {
                remainingWaterTextView.setText(remainingWater + " " + dash_ml.getText()); // Display units if remaining
            } else {
                remainingWaterTextView.setText("0"); // Display 0 if remaining water is 0 or less
            }

            if (roundedPercentage == 100) {
                // Execute the saveStreakData method
                saveStreakData(1);
            }
        } else {
            // Handle the case where the goal is 0 or negative
            progressBar.setProgress(0);
            remainingWaterTextView.setText("0"); // Display 0 if goal is 0 or negative
        }



    }









    private void waterLevelRealtime() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            String currentDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(new Date());

            DocumentReference documentReference = firestore.collection("level-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate);

            // Fetch initial data and attach listener for real-time updates
            documentReference.addSnapshotListener((snapshot, error) -> {
                if (error != null) {
                    // Handle errors while fetching data
                    Toast.makeText(HomePage.this, "Failed to fetch water intake data: " + error.getMessage(), Toast.LENGTH_SHORT).show();
                    return;
                }

                if (snapshot != null && snapshot.exists()) {
                    String intakeValueString = snapshot.getString("water_value");
                    String timeString = snapshot.getString("time");

                    // Get current time
                    String currentTime = new SimpleDateFormat("HH:mm:ss", Locale.getDefault()).format(new Date());
                    int totalWaterIntake = 0;
                    if (timeString != null && timeString.equals(currentTime)) {
                        if (intakeValueString != null && !intakeValueString.trim().isEmpty()) {
                            try {
                                totalWaterIntake = Integer.parseInt(intakeValueString.trim());
                                waterLevel.setText(String.valueOf(totalWaterIntake));
                            } catch (NumberFormatException e) {
                                e.printStackTrace();
                            }
                        }
                    }

                    // Log the total water intake


                    // Update the TextView with the total water intake
                    int bottle = 1600;

                    // Update the progress bar
                    updateProgressLevelBar(totalWaterIntake, bottle);
                }
            });
        }
    }

    private void updateProgressLevelBar(int totalWaterIntake, int goalValue) {
        WaveProgressBar progressLevelBar = findViewById(R.id.progressLevelBar);

        if (goalValue > 0) {
            // Calculate the percentage of completion
            double percentage = ((double) totalWaterIntake / goalValue) * 100;

            // Ensure the percentage is within the valid range [0, 100]
            percentage = Math.min(100, Math.max(0, percentage));

            // Set the maximum progress to 100 to represent 100%
            progressLevelBar.setMax(100);

            // Update the progress bar
            progressLevelBar.setProgress((int) percentage);

            // Display only whole numbers for the percentage
            int roundedPercentage = (int) Math.round(percentage);

            if (roundedPercentage == 100) {
                // Execute the saveStreakData method
                // saveStreakData(1);
            }
        } else {
            // Handle the case where the goal is 0 or negative
            progressLevelBar.setProgress(0);
        }
    }


    private void fetchWaterVal() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());


            firestore.collection("notif-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .limit(1)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Log.e("notif", "failed getting dataa");

                                return;
                            }

                            boolean waterDataExists = false;

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("water_value");
                                    if (intakeValue != null && intakeValue.equals("0")) {
                                        // Water value is "0"
                                        waterDataExists = true;
                                    }

                                }

                                // Notify the adapter of data change


                            }
                            if (waterDataExists) {
                                refill.setEnabled(false);
                            } else {
                                refill.setEnabled(true);
                            }
                        }
                    });
        }
    }



    private void updateTextView(int totalWaterIntake) {
        // Update your TextView with the calculated total water intake
        TextView textView = findViewById(R.id.waterIntake);
        textView.setText(String.valueOf(totalWaterIntake));
    }



}