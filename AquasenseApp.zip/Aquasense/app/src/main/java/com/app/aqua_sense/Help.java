package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.view.View;
import android.widget.AdapterView;
import android.widget.ArrayAdapter;
import android.widget.ImageView;
import android.widget.Spinner;
import android.widget.TextView;
import android.widget.Toast;

public class Help extends AppCompatActivity implements AdapterView.OnItemSelectedListener {

    ImageView backbutton;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_help);

        backbutton = findViewById(R.id.backbutton);

        backbutton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);

                // Finish the RecordsActivity to go back to the HomePage
                finish();
            }
        });




        Spinner spinner = findViewById(R.id.spinner);
        setupSpinner(spinner, R.array.spinner_items);

        Spinner spinner1 = findViewById(R.id.spinner1);
        setupSpinner(spinner1, R.array.spinner_items1);

        Spinner spinner2 = findViewById(R.id.spinner2);
        setupSpinner(spinner2, R.array.spinner_items2);



    }

    private void setupSpinner(Spinner spinner, int arrayResourceID) {
        ArrayAdapter<CharSequence> adapter = ArrayAdapter.createFromResource(
                this,
                arrayResourceID,
                R.layout.color_spinner_layout
        );

        adapter.setDropDownViewResource(R.layout.spinner_dropdown_layout);
        spinner.setAdapter(adapter);
        spinner.setOnItemSelectedListener(this);
    }

    @Override
    public void onItemSelected(AdapterView<?> adapterView, View view, int i, long l) {
        Toast.makeText(this,adapterView.getSelectedItem().toString(), Toast.LENGTH_SHORT).show();
    }

    @Override
    public void onNothingSelected(AdapterView<?> adapterView) {

    }


}