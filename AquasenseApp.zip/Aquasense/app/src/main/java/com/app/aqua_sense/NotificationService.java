package com.app.aqua_sense;

import android.app.Notification;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.app.Service;
import android.content.Intent;
import android.os.Build;
import android.os.IBinder;
import android.util.Log;

import androidx.annotation.Nullable;
import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.SimpleDateFormat;
import java.util.Date;
import java.util.Locale;

public class NotificationService extends Service {

    private static final String CHANNEL_ID = "AquaSense";
    private static final int NOTIFICATION_ID = 1;
    @Override
    public int onStartCommand(Intent intent, int flags, int startId) {
        Log.d("NotificationService", "Service started");
        // Implement your logic here
        // This method will be called when the service is started

        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            String currentDate = sdfDate.format(new Date());

            firestore.collection("notif-history")
                    .document(userEmail)
                    .collection("water_intake")
                    .document(currentDate)  // Adjust this according to your requirements
                    .collection("entries")
                    .orderBy("time", Query.Direction.DESCENDING)
                    .addSnapshotListener(new EventListener<QuerySnapshot>() {
                        @Override
                        public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {
                            if (e != null) {
                                // Handle errors while fetching data
                                Log.e("notif", "failed getting dataa");

                                return;
                            }

                            SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm", Locale.getDefault());
                            String currentTime = sdfTime.format(new Date());

                            if (queryDocumentSnapshots != null) {
                                for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                    String intakeValue = document.getString("intake_value");
                                    String units = document.getString("units");
                                    String time = document.getString("time");
                                    String waterVal = document.getString("water_value");

                                    String databaseTime = time.substring(0, 5); // Assuming time format is HH:mm:ss

                                    // Check if the time from the database (HH:mm) matches the current time (HH:mm)
                                    if (databaseTime.equals(currentTime)) {
                                        createNotificationChannel();
//                                    buildNotification(intakeValue, units, time);
                                        showNotification(intakeValue, units, time, waterVal);
                                    }
                                }

                                 // Notify the adapter of data change

                                Log.e("notif", "GET DATA");
                            } else {
                                // Handle errors while fetching data
                                Log.e("notif", "error");
                            }
                        }
                    });
        }

        return START_STICKY; // or other appropriate return value
    }



    private void createNotificationChannel() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.O) {
            CharSequence name = "Threshold Exceeded";
            String description = "Notifications for threshold exceeded.";
            int importance = NotificationManager.IMPORTANCE_HIGH;
            NotificationChannel channel = new NotificationChannel("threshold_channel", name, importance);
            channel.setDescription(description);
            // Register the channel with the system
            NotificationManager notificationManager = getSystemService(NotificationManager.class);
            notificationManager.createNotificationChannel(channel);
        }
    }


    private void showNotification(String intakeValue, String units, String time, String waterVal) {


        // Create Yes and No Intents with your desired actions (replace with your logic)

        Intent yesIntent = new Intent(this, NotificationActionReceiver.class);
        yesIntent.setAction("ACTION_YES");
        yesIntent.putExtra("intakeValue", intakeValue);
        yesIntent.putExtra("units", units);
        yesIntent.putExtra("time", time);
        yesIntent.putExtra("waterVal", waterVal);
        PendingIntent yesPendingIntent = PendingIntent.getBroadcast(this, 0, yesIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        Intent noIntent = new Intent(this, NotificationActionReceiver.class);
        noIntent.setAction("ACTION_NO");
        PendingIntent noPendingIntent = PendingIntent.getBroadcast(this, 1, noIntent, PendingIntent.FLAG_UPDATE_CURRENT);

        // Notification actions
        NotificationCompat.Action yesAction = new NotificationCompat.Action.Builder(R.drawable.baseline_check_24, "Yes", yesPendingIntent).build();
        NotificationCompat.Action noAction = new NotificationCompat.Action.Builder(R.drawable.baseline_close_24, "No", noPendingIntent).build();

        // Vibrate and sound on notification
        long[] vibratePattern = {0, 300, 0, 300}; // Customize vibration pattern (optional)
        NotificationCompat.Builder builder = new NotificationCompat.Builder(this, "threshold_channel")
                .setSmallIcon(R.drawable.baseline_notifications_24)
                .setContentTitle("Aquasense")
                .setContentText("Do you want to record " + intakeValue + " " + units + " at " + time + " as your drink?")
                .setPriority(NotificationCompat.PRIORITY_DEFAULT)
                .setAutoCancel(true)
                .setVibrate(vibratePattern)  // Set vibration pattern
                .setDefaults(NotificationCompat.DEFAULT_ALL)
                .addAction(yesAction)
                .addAction(noAction);

        // Show the notification
        NotificationManager notificationManager = getSystemService(NotificationManager.class);
        notificationManager.notify(NOTIFICATION_ID, builder.build());


        notificationManager.cancel(NOTIFICATION_ID); // Cancel the notification
        builder.setDefaults(NotificationCompat.DEFAULT_LIGHTS); // Reset defaults (no sound/vibration)
        notificationManager.notify(NOTIFICATION_ID, builder.build()); // Re-notify with reset defaults
    }


//    private void buildNotification(String intakeValue, String units, String time) {
//        // Create an Intent to handle the action when the user clicks on the notification
//        Intent yesIntent = new Intent(this, NotificationActionReceiver.class);
//        yesIntent.setAction("ACTION_YES");
//        yesIntent.putExtra("intakeValue", intakeValue);
//        yesIntent.putExtra("units", units);
//        yesIntent.putExtra("time", time);
//        PendingIntent yesPendingIntent = PendingIntent.getBroadcast(this, 0, yesIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//
//        Intent noIntent = new Intent(this, NotificationActionReceiver.class);
//        noIntent.setAction("ACTION_NO");
//        PendingIntent noPendingIntent = PendingIntent.getBroadcast(this, 0, noIntent, PendingIntent.FLAG_UPDATE_CURRENT);
//
//        // Create a notification channel for Android Oreo and higher
//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//            NotificationChannel channel = new NotificationChannel(CHANNEL_ID, "AquaSense Notifications", NotificationManager.IMPORTANCE_HIGH);
//            channel.enableVibration(true);
//            channel.setSound(android.provider.Settings.System.DEFAULT_NOTIFICATION_URI, null);
//
//            NotificationManager notificationManager = getSystemService(NotificationManager.class);
//            notificationManager.createNotificationChannel(channel);
//        }
//
//        // Build the notification
//        Notification notification = null;
//        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.O) {
//            notification = new Notification.Builder(this, CHANNEL_ID)
//                    .setContentTitle("AquaSense")
//                    .setContentText("Do you want to record " + intakeValue + " " + units + " at " + time + " as your drink?")
//                    .setSmallIcon(R.drawable.baseline_notifications_24)
//                    .addAction(android.R.drawable.ic_menu_edit, "Yes", yesPendingIntent)
//                    .addAction(android.R.drawable.ic_menu_close_clear_cancel, "No", noPendingIntent)
//                    .build();
//        }
//
//        // Show the notification
//        NotificationManager notificationManager = getSystemService(NotificationManager.class);
//        notificationManager.notify(NOTIFICATION_ID, notification);
//    }

    private void handleNewData(QuerySnapshot queryDocumentSnapshots) {
        // Implement your logic here to handle new data
        // This function will be called every time new data is received
    }

    @Nullable
    @Override
    public IBinder onBind(Intent intent) {
        return null;
    }
}
