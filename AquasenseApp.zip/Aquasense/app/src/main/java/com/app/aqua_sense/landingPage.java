package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.text.TextUtils;
import android.util.Log;
import android.view.View;
import android.widget.Button;
import android.widget.Toast;

import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.DocumentReference;
import com.google.firebase.firestore.DocumentSnapshot;
import com.google.firebase.firestore.FirebaseFirestore;

public class landingPage extends AppCompatActivity {


    FirebaseFirestore firebaseFirestore = FirebaseFirestore.getInstance();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_landing_page);
        FirebaseAuth firebaseAuth = FirebaseAuth.getInstance();
        FirebaseUser currentUser = firebaseAuth.getCurrentUser();

        if (currentUser != null && currentUser.isEmailVerified()) {
            String userId = currentUser.getEmail();
            Log.d("landingPage", "User is logged in and email is verified"+userId);
            // Assume you have a Firestore collection named "users" and a document with the user's ID
            DocumentReference userRef = firebaseFirestore.collection("users").document(userId);

            userRef.get().addOnCompleteListener(task -> {
                if (task.isSuccessful()) {
                    DocumentSnapshot document = task.getResult();



                            // Time and water_goal are not empty, navigate to Dashboard
                            Intent intent = new Intent(landingPage.this, HomePage.class);
                            startActivity(intent);
                            finish();


                }
                    // Handle the failure to fetch data from Firestore


            });
        } else {
            // Either current user is null or email is not verified, handle accordingly
            if (currentUser == null) {

            } else {

            }

        }



        Button loginButton = findViewById(R.id.login);
        Button signupButton = findViewById(R.id.signup);

        loginButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(landingPage.this, LoginPage.class);
                startActivity(intent);
            }
        });

        signupButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {

                Intent intent = new Intent(landingPage.this, RegistrationPage.class);
                startActivity(intent);
            }
        });
    }


}