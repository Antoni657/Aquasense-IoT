package com.app.aqua_sense;

import android.content.Intent;
import android.os.Bundle;
import android.util.Log;
import android.view.View;
import android.widget.ImageView;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import com.github.mikephil.charting.charts.BarChart;
import com.github.mikephil.charting.components.XAxis;
import com.github.mikephil.charting.data.BarData;
import com.github.mikephil.charting.data.BarDataSet;
import com.github.mikephil.charting.data.BarEntry;
import com.github.mikephil.charting.formatter.IndexAxisValueFormatter;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.firestore.EventListener;
import com.google.firebase.firestore.FirebaseFirestore;
import com.google.firebase.firestore.FirebaseFirestoreException;
import com.google.firebase.firestore.Query;
import com.google.firebase.firestore.QueryDocumentSnapshot;
import com.google.firebase.firestore.QuerySnapshot;

import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Calendar;
import java.util.Collections;
import java.util.Comparator;
import java.util.Date;
import java.util.HashMap;
import java.util.List;
import java.util.Locale;
import java.util.Map;

public class History extends AppCompatActivity {

    BarChart barChart;
    TextView backButton, weeksLabel, goal, average, frequency, percentage;
    ImageView nextBtn, prevBtn;
    Calendar calendar;
    private int counter = 0;
    private int intakeCounter = 0;
    private int sum = 0;
    private int freqsum = 0;
    ArrayList<Integer> intakeValues = new ArrayList<>();

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_history);

        backButton = findViewById(R.id.backButton);
        weeksLabel = findViewById(R.id.weeks);
        nextBtn = findViewById(R.id.next);
        prevBtn = findViewById(R.id.prev);
        goal = findViewById(R.id.goal);
        average = findViewById(R.id.ave);
        frequency = findViewById(R.id.freq);
        percentage = findViewById(R.id.avePercent);

         barChart = findViewById(R.id.barChart);
        calendar = Calendar.getInstance();
        displayWeeklyDateRange();
        fetchWaterVal();


        backButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent resultIntent = new Intent();
                setResult(RESULT_OK, resultIntent);

                // Finish the RecordsActivity to go back to the HomePage
                finish();
            }
        });

        prevBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to previous week
                goal.setText("");
                calendar.add(Calendar.WEEK_OF_YEAR, -1);
                displayWeeklyDateRange();
                fetchWaterVal();

            }
        });

        nextBtn.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {
                // Move to next week
                goal.setText("");
                calendar.add(Calendar.WEEK_OF_YEAR, 1);
                displayWeeklyDateRange();
                fetchWaterVal();

            }
        });


    }



    private void fetchWaterVal() {
        FirebaseFirestore firestore = FirebaseFirestore.getInstance();
        FirebaseUser currentUser = FirebaseAuth.getInstance().getCurrentUser();
        Log.e("fetchWaterVal", "first ");

        if (currentUser != null) {
            String userEmail = currentUser.getEmail();
            SimpleDateFormat sdfDate = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Log.e("fetchWaterVal", "first "+userEmail);
            // Get the displayed dates from the textview
            String displayedDateRange = weeksLabel.getText().toString();
            String[] dates = displayedDateRange.split(" / "); // Split on hyphen (-)
            String startDateStr = dates[0];
            String endDateStr = dates[1];
            int totalIntakeForValidDays = 0;
            int totalValidDays = 0;
            // Convert displayed dates to Date objects
            try {
                Date startDate = sdfDate.parse(startDateStr);
                Date endDate = sdfDate.parse(endDateStr);
                List<String> intakeDates = new ArrayList<>();
                List<Integer> totalIntakeValues = new ArrayList<>();

                // Loop through all dates within the week
                for (Date currentDay = startDate; currentDay.compareTo(endDate) <= 0; currentDay.setDate(currentDay.getDate() + 1)) {
                    String currentDateStr = sdfDate.format(currentDay);
                    counter = 0;
                    intakeCounter = 0;
                    sum = 0;
                    freqsum = 0;
                    // Modify your Firestore query to filter by the current date
                    firestore.collection("water-history")
                            .document(userEmail)
                            .collection("water_intake")
                            .whereEqualTo("date", currentDateStr) // Filter by current date
                            .get() // Perform a single document fetch for each date
                            .addOnSuccessListener(new OnSuccessListener<QuerySnapshot>() {
                                @Override
                                public void onSuccess(QuerySnapshot queryDocumentSnapshots) {


                                    firestore.collection("water-history")
                                            .document(userEmail)
                                            .collection("water_intake")
                                            .document(currentDateStr)
                                            .collection("entries")
                                            .orderBy("time", Query.Direction.DESCENDING)

                                            .addSnapshotListener(new EventListener<QuerySnapshot>() {
                                                @Override
                                                public void onEvent(@Nullable QuerySnapshot queryDocumentSnapshots, @Nullable FirebaseFirestoreException e) {

                                                    if (e != null) {
                                                        // Handle errors while fetching data
                                                        Log.e("notif", "failed getting dataa");

                                                        return;
                                                    }

                                                    SimpleDateFormat sdfTime = new SimpleDateFormat("HH:mm", Locale.getDefault());
                                                    String currentTime = sdfTime.format(new Date());
                                                    int totalIntake = 0;
                                                    int totalIntakeForDay = 0;
                                                    int intakeCountForDay = 0;
                                                    if (queryDocumentSnapshots != null) {
                                                        for (QueryDocumentSnapshot document : queryDocumentSnapshots) {
                                                            String intakeValue = document.getString("intake_value");
                                                            String time = document.getString("time");
                                                            String date = document.getString("date");
                                                            Log.d("notif", "intake" + intakeValue);
                                                            Log.d("notif", "time" + time);
                                                            Log.d("notif", "date" + date);


                                                            totalIntake += Integer.parseInt(intakeValue);
                                                            totalIntakeForDay += Integer.parseInt(intakeValue);
                                                            intakeCountForDay++;



                                                        }

                                                        intakeDates.add(currentDateStr);
                                                        totalIntakeValues.add(totalIntakeForDay);

                                                        // Notify the adapter of data change


                                                    } else {
                                                        // Handle errors while fetching data
                                                        Log.e("notif", "error");

                                                    }

                                                    if (intakeCountForDay > 0) {
                                                        int sumIntakeForDay = totalIntakeForDay ;

                                                        sum += sumIntakeForDay;
                                                        freqsum += intakeCountForDay;
                                                        Log.e("notif", "ave "+sumIntakeForDay);

                                                        // Now you can use averageIntakeForDay and frequencyForDay to calculate overall averages

                                                    }
                                                    Log.d("TotalIntake", "Total intake for " + currentDateStr + ": " + totalIntake);

                                                    plotBarGraph(intakeDates, totalIntakeValues);
                                                    if (totalIntake >= 3000) {
                                                        // Increment counter
                                                        counter++;

                                                        // Update TextView to display counter value
                                                        Log.d("Counter", "Counter: " + counter);

                                                        goal.setText(String.valueOf(counter));

                                                    }
                                                    if (totalIntake >0 ){
                                                        intakeCounter++;
                                                        int averageIntake = sum / intakeCounter;
                                                        int averageFreq = freqsum / intakeCountForDay;
                                                        Log.e("notif", "freq "+averageIntake);

                                                        double percent = (double) counter / 7 * 100;
                                                        String formattedPercent = String.format("%.2f", percent);


                                                        average.setText(String.valueOf(averageIntake));
                                                        frequency.setText(String.valueOf(averageFreq));
                                                        percentage.setText(formattedPercent);



                                                    }


                                                    if (counter == 0){
                                                        goal.setText("0");
                                                        average.setText("0");
                                                        percentage.setText("0");
                                                        frequency.setText("0");
                                                    }


                                                }
                                            });



                                }
                            })
                            .addOnFailureListener(new OnFailureListener() {
                                @Override
                                public void onFailure(@NonNull Exception e) {
                                    // Handle errors while fetching data for this date
                                    Log.e("fetchWaterVal", "Error fetching water data for " + currentDateStr + ": " + e.getMessage());
                                }
                            });

                }
            } catch (ParseException e) {
                // Handle parsing errors
                Log.e("fetchWaterVal", "Error parsing displayed dates: " + e.getMessage());
            }
        }
    }

    private void plotBarGraph(List<String> intakeDates, List<Integer> totalIntakeValues) {


        Map<String, Integer> dataMap = new HashMap<>();
        for (int i = 0; i < intakeDates.size(); i++) {
            dataMap.put(intakeDates.get(i), totalIntakeValues.get(i));
        }

        // Sort the map by date
        List<Map.Entry<String, Integer>> sortedEntries = new ArrayList<>(dataMap.entrySet());
        Collections.sort(sortedEntries, new Comparator<Map.Entry<String, Integer>>() {
            @Override
            public int compare(Map.Entry<String, Integer> o1, Map.Entry<String, Integer> o2) {
                return o1.getKey().compareTo(o2.getKey());
            }
        });

        // Extract sorted dates and total intake values
        List<String> sortedDates = new ArrayList<>();
        List<Integer> sortedTotalIntakeValues = new ArrayList<>();
        for (Map.Entry<String, Integer> entry : sortedEntries) {
            sortedDates.add(entry.getKey());
            sortedTotalIntakeValues.add(entry.getValue());


        }
        List<String> abbreviatedWeekdays = new ArrayList<>();
        for (String dateString : sortedDates) {
            abbreviatedWeekdays.add(getAbbreviatedWeekday(dateString));
        }
        ArrayList<BarEntry> entries = new ArrayList<>();
        for (int i = 0; i < sortedTotalIntakeValues.size(); i++) {
            entries.add(new BarEntry(i, sortedTotalIntakeValues.get(i)));
        }

        BarDataSet dataSet = new BarDataSet(entries, "Total Intake");
        BarData barData = new BarData(dataSet);
        barChart.setData(barData);

        // Formatting X-axis with sorted dates
        XAxis xAxis = barChart.getXAxis();
        xAxis.setValueFormatter(new IndexAxisValueFormatter(abbreviatedWeekdays));
        xAxis.setPosition(XAxis.XAxisPosition.BOTTOM);
        xAxis.setGranularity(1);

        // Refresh the chart
        barChart.invalidate();
    }

    private String getAbbreviatedWeekday(String dateString) {
        try {
            SimpleDateFormat sdf = new SimpleDateFormat("yyyy-MM-dd", Locale.getDefault());
            Date date = sdf.parse(dateString);
            SimpleDateFormat sdfOut = new SimpleDateFormat("EEE", Locale.getDefault());
            return sdfOut.format(date);
        } catch (ParseException e) {
            e.printStackTrace();
            return ""; // Return empty string in case of parsing error
        }
    }

    private void displayWeeklyDateRange() {
//        Date currentDate = new Date();
//        Calendar calendar = Calendar.getInstance();
//        calendar.setTime(currentDate);

        // Find the start date of the current week (Sunday)
        calendar.set(Calendar.DAY_OF_WEEK, Calendar.SUNDAY);
        Date startDate = calendar.getTime();

        // Find the end date of the current week (Saturday)
        calendar.add(Calendar.DAY_OF_WEEK, 6);
        Date endDate = calendar.getTime();

        // Format the dates
        SimpleDateFormat dateFormat = new SimpleDateFormat("yyyy-MM-dd");
        String startDateFormat = dateFormat.format(startDate);
        String endDateFormat = dateFormat.format(endDate);

        // Display the weekly date range
        String weeklyDateRange = startDateFormat + " / " + endDateFormat;
        weeksLabel.setText(weeklyDateRange);
    }
}