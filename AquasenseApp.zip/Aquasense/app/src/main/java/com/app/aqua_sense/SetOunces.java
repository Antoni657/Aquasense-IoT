package com.app.aqua_sense;

import androidx.appcompat.app.AppCompatActivity;

import android.annotation.SuppressLint;
import android.content.Intent;
import android.os.Bundle;
import android.text.InputFilter;
import android.view.View;
import android.view.Window;
import android.view.WindowManager;
import android.widget.EditText;
import android.widget.TextView;

public class SetOunces extends AppCompatActivity {

    TextView mililiter,ounce, finish;
    EditText ML;

    @SuppressLint("MissingInflatedId")
    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        setContentView(R.layout.activity_set_ounces);

        ML = findViewById(R.id.ML);
        mililiter = findViewById(R.id.mililiter);
        ounce = findViewById(R.id.ounce);
        finish = findViewById(R.id.finish);

        ML.setFilters(new InputFilter[]{new NumericInputFilter()});

        mililiter.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ML.setText("0 ML");
            }
        });

        ounce.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                ML.setText("0 Oz");
            }
        });
    }

    public void finish(View view) {
        String mlValue = ML.getText().toString();
        finish.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View view) {
                Intent intent = new Intent(SetOunces.this, HomePage.class);
                intent.putExtra("mlValue", mlValue);
                startActivity(intent);
            }
        });

    }
}